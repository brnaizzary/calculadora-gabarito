"""Servidor da calculadora de quebra de gabarito (R.Yazbek – Novos Negócios)."""
from __future__ import annotations

import asyncio
import json
import threading
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import geosampa, pipeline
from .config import gabaritos, salvar_gabaritos, validar_gabaritos
from .modelo import normalizar_entrada

STATIC = Path(__file__).resolve().parent.parent / "static"
app = FastAPI(title="Quebra de Gabarito – R.Yazbek")


@app.middleware("http")
async def sem_cache_da_tela(request, call_next):
    """Tela e arquivos estáticos: o navegador confere a versão a cada acesso (ETag), para que
    os colegas vejam a versão nova logo depois de uma atualização do app."""
    resposta = await call_next(request)
    caminho = request.url.path
    if caminho == "/" or caminho.startswith("/static/"):
        resposta.headers["Cache-Control"] = "no-cache"
    if caminho in ("/", "/static/cartao_app.png"):
        _registrar_acesso(request, resposta.status_code)
    return resposta


def _registrar_acesso(request, status: int) -> None:
    """Diagnóstico da prévia do link: registra quem buscou a página e a imagem do cartão (navegador ou
    WhatsApp) em %LOCALAPPDATA%\\CalcGabarito\\acessos.log. Só data, método, caminho, status e navegador."""
    from datetime import datetime
    from .config import pasta_cache
    try:
        arq = pasta_cache().parent / "acessos.log"
        ua = request.headers.get("user-agent", "")[:160]
        with open(arq, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%d/%m/%Y %H:%M:%S}\t{request.method}\t{request.url.path}\t{status}\t{ua}\n")
    except OSError:
        pass


class Pedido(BaseModel):
    setor: str | None = None
    quadra: str | None = None
    sql: str | None = None
    gabarito_m: float | None = None
    criterio_edificado: str | None = None
    altura_minima_edificado_m: float | None = None
    alturas_manuais: dict[str, dict] | None = None
    estudo: list[str] | None = None
    recarregar: bool = False


def _sq(setor, quadra, sql):
    try:
        return normalizar_entrada(setor, quadra, sql)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.post("/api/analisar")
def analisar(p: Pedido):
    """Coleta (ou usa o cache) e calcula. Recalcular com outro gabarito ou altura manual
    reaproveita os dados em memória: não consulta o GeoSampa de novo."""
    s, q = _sq(p.setor, p.quadra, p.sql)
    dados = pipeline.coletar(s, q, usar_cache=not p.recarregar)
    return pipeline.analisar(dados, p.gabarito_m, p.criterio_edificado,
                             p.altura_minima_edificado_m, p.alturas_manuais, p.estudo)


def _resultado(p: Pedido) -> dict:
    s, q = _sq(p.setor, p.quadra, p.sql)
    dados = pipeline.coletar(s, q, usar_cache=not p.recarregar)
    return pipeline.analisar(dados, p.gabarito_m, p.criterio_edificado,
                             p.altura_minima_edificado_m, p.alturas_manuais, p.estudo)


def _nome(r: dict, ext: str) -> str:
    from datetime import date
    i = r["identificacao"]
    return f'quebra-gabarito_{i["setor"]}-{i["quadra"]}_{date.today():%Y-%m-%d}.{ext}'


@app.post("/api/relatorio.pdf")
def relatorio_pdf(p: Pedido):
    """Relatório técnico (A4, até 4 páginas) com os mesmos parâmetros da tela."""
    from .relatorio import gerar_pdf
    r = _resultado(p)
    return Response(gerar_pdf(r), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{_nome(r, "pdf")}"'})


@app.post("/api/planilha.xlsx")
def planilha_xlsx(p: Pedido):
    """Planilha com fórmulas vivas (gabarito como célula-parâmetro)."""
    from .planilha import gerar_xlsx
    r = _resultado(p)
    return Response(gerar_xlsx(r),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{_nome(r, "xlsx")}"'})


@app.get("/api/analisar/stream")
async def analisar_stream(setor: str | None = None, quadra: str | None = None, sql: str | None = None,
                          recarregar: bool = False):
    """Mesma análise, emitindo cada etapa real da coleta (Server-Sent Events)."""
    s, q = _sq(setor, quadra, sql)
    loop = asyncio.get_running_loop()
    fila: asyncio.Queue = asyncio.Queue()

    def trabalho():
        try:
            dados = pipeline.coletar(s, q, usar_cache=not recarregar,
                                     progresso=lambda e: loop.call_soon_threadsafe(fila.put_nowait, ("etapa", e)))
            loop.call_soon_threadsafe(fila.put_nowait, ("etapa", "calculo"))
            loop.call_soon_threadsafe(fila.put_nowait, ("resultado", pipeline.analisar(dados)))
        except Exception as e:  # nunca deixar o usuário sem resposta
            loop.call_soon_threadsafe(fila.put_nowait, ("erro", f"{type(e).__name__}: {e}"))

    threading.Thread(target=trabalho, daemon=True).start()

    async def eventos():
        while True:
            tipo, dado = await fila.get()
            yield f"event: {tipo}\ndata: {json.dumps(dado, ensure_ascii=False, default=str)}\n\n"
            if tipo in ("resultado", "erro"):
                break

    return StreamingResponse(eventos(), media_type="text/event-stream")


TIPOS_IMAGEM = {"image/png", "image/jpeg", "image/webp", "image/gif", "image/bmp", "image/tiff"}


@app.post("/api/imagem")
async def identificar_imagem(arquivo: UploadFile = File(...)):
    """Lê um print da quadra e devolve candidatas. O cálculo só roda depois da confirmação na tela."""
    from . import imagem
    if arquivo.content_type not in TIPOS_IMAGEM:
        raise HTTPException(415, "Envie uma imagem (PNG, JPG ou WEBP).")
    conteudo = await arquivo.read(10 * 1024 * 1024 + 1)
    if len(conteudo) > 10 * 1024 * 1024:
        raise HTTPException(413, "Imagem maior que 10 MB.")
    try:
        return await asyncio.to_thread(imagem.analisar_imagem, conteudo)
    except imagem.TesseractAusente as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(422, f"Não foi possível ler a imagem ({type(e).__name__}).")


@app.get("/api/gabaritos")
def ler_gabaritos():
    return gabaritos()


@app.put("/api/gabaritos")
def gravar_gabaritos(dados: dict):
    """Grava a tabela do Quadro 3 editada na tela. Valida cada linha antes de salvar."""
    try:
        tabela = validar_gabaritos(dados)
    except ValueError as e:
        raise HTTPException(422, str(e))
    salvar_gabaritos(tabela)
    return {"ok": True, "zonas": len(tabela["zonas"])}


@app.get("/api/camadas")
def camadas_disponiveis(busca: str = ""):
    """Descobre nomes de camadas no GetCapabilities do GeoSampa (ex.: busca=zon)."""
    try:
        return {"camadas": geosampa.listar_camadas(busca)}
    except Exception as e:
        raise HTTPException(502, f"GeoSampa indisponível: {e}")


@app.post("/api/cache/limpar")
def limpar_cache():
    pipeline._memoria.clear()
    return {"removidos": geosampa.limpar_cache()}


@app.api_route("/", methods=["GET", "HEAD"])  # quem monta a prévia do link costuma consultar com HEAD antes
def index(request: Request):
    # Prévia do link (WhatsApp, Teams): as metatags og: precisam de endereço completo da imagem.
    base = str(request.base_url).rstrip("/")
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    html = html.replace('content="/static/', f'content="{base}/static/')
    html = html.replace('<meta property="og:type"', f'<meta property="og:url" content="{base}/">\n<meta property="og:type"', 1)
    return HTMLResponse(html)


# Arquivos do app instalável (PWA). O service worker precisa estar na raiz para valer para o site todo.
@app.get("/sw.js")
def service_worker():
    return FileResponse(STATIC / "sw.js", media_type="application/javascript; charset=utf-8", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest")
def manifesto():
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/favicon.ico")
def favicon():
    return FileResponse(STATIC / "favicon.ico", media_type="image/x-icon")


app.mount("/static", StaticFiles(directory=STATIC), name="static")
