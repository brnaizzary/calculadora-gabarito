"""Monta o modelo da quadra a partir das feições do GeoSampa.

- Lote físico: agrupa registros de lote_cidadao. Condomínio (cd_lote = 0000 e
  cd_condominio ≠ 00) vira um único lote; lote sem SQL vira "via de acesso".
- Área MDC = área do polígono (fórmula de Gauss/shoelace, via Shapely), em m².
- Área IPTU = qt_area_terreno.
- Edificação → lote pelo ponto interno do polígono (point-in-polygon).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from pyproj import Transformer
from shapely.geometry import shape, mapping
from shapely.geometry.base import BaseGeometry
from shapely.ops import transform, unary_union

from .config import camadas

# ---------------------------------------------------------------- entradas

_RE_SQL = re.compile(r"^\s*(\d{3})\.?(\d{3})\.?(\d{4})-?(\d)?\s*$")


def normalizar_entrada(setor: str | None = None, quadra: str | None = None,
                       sql: str | None = None) -> tuple[str, str]:
    """Aceita setor+quadra (com ou sem zeros) ou SQL completo (011.089.0060-7)."""
    if sql:
        m = _RE_SQL.match(sql)
        if not m:
            raise ValueError(f"SQL inválido: {sql!r}. Formato esperado: 011.089.0060-7")
        return m.group(1), m.group(2)
    if setor is None or quadra is None:
        raise ValueError("Informe setor e quadra, ou o SQL completo.")
    s, q = str(setor).strip(), str(quadra).strip()
    if _RE_SQL.match(s):  # usuário colou o SQL no campo setor
        return normalizar_entrada(sql=s)
    if not (s.isdigit() and q.isdigit() and len(s) <= 3 and len(q) <= 3):
        raise ValueError("Setor e quadra devem ter até 3 dígitos numéricos cada.")
    return s.zfill(3), q.zfill(3)


def formatar_sql(setor: str, quadra: str, lote: str, digito: str | None) -> str:
    return f"{setor}.{quadra}.{lote}" + (f"-{digito}" if digito not in (None, "") else "")


# ---------------------------------------------------------------- geometria

_wgs_para_utm = Transformer.from_crs("EPSG:4326", "EPSG:31983", always_xy=True).transform


def geometria_utm(geojson_geom: dict) -> BaseGeometry:
    """Converte para Shapely garantindo metros em EPSG:31983. Se o servidor ignorar
    srsName e devolver graus, reprojeta (detectado pela ordem de grandeza)."""
    g = shape(geojson_geom)
    minx, miny, maxx, maxy = g.bounds
    if -180 <= minx <= 180 and -90 <= miny <= 90 and -180 <= maxx <= 180 and -90 <= maxy <= 90:
        g = transform(_wgs_para_utm, g)
    if not g.is_valid:
        g = g.buffer(0)
    return g


def _vazio(v) -> bool:
    return v is None or (isinstance(v, str) and v.strip() in ("", "0", "00", "0000"))


def _num(v) -> float | None:
    if v is None or v == "":
        return None
    try:
        return float(str(v).replace(",", "."))
    except ValueError:
        return None


# ---------------------------------------------------------------- domínio

@dataclass
class Edificacao:
    id: str
    geom: BaseGeometry
    altura_mdc: float | None
    lote_id: str | None = None
    avisos: list[str] = field(default_factory=list)

    @property
    def area_projecao(self) -> float:
        return self.geom.area


@dataclass
class Lote:
    id: str                         # rótulo: "CD 12", "F0002", "VIA 1"
    tipo: str                       # "fiscal" | "condominio" | "via_acesso"
    geom: BaseGeometry
    area_iptu: float | None
    sql: str | None
    cd_lote: str | None
    cd_condominio: str | None
    endereco: str | None
    tipo_uso: str | None
    area_construida: float | None
    n_registros: int
    edificacoes: list[Edificacao] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)

    @property
    def area_mdc(self) -> float:
        return self.geom.area

    @property
    def tem_sql(self) -> bool:
        return self.tipo != "via_acesso"

    @property
    def diferenca_pct(self) -> float | None:
        """(MDC − IPTU) ÷ IPTU × 100."""
        if not self.area_iptu:
            return None
        return (self.area_mdc - self.area_iptu) / self.area_iptu * 100

    @property
    def altura_mdc_max(self) -> float | None:
        hs = [e.altura_mdc for e in self.edificacoes if e.altura_mdc is not None]
        return max(hs) if hs else None


def montar_lotes(features: list[dict], setor: str, quadra: str) -> tuple[list[Lote], list[str]]:
    f = camadas()["lote"]
    grupos: dict[tuple, list[dict]] = {}
    n_via = 0
    for feat in features:
        p = feat.get("properties", {})
        cd_lote = (str(p.get(f["campo_lote"])).strip() if p.get(f["campo_lote"]) is not None else None)
        cd_cond = (str(p.get(f["campo_condominio"])).strip() if p.get(f["campo_condominio"]) is not None else None)
        tipo_lote = str(p.get(f.get("campo_tipo_lote", ""), "") or "").strip().upper()
        if tipo_lote and tipo_lote in f.get("valores_via_acesso", []):
            n_via += 1
            chave = ("via_acesso", str(n_via))
        elif _vazio(cd_lote) and not _vazio(cd_cond):
            chave = ("condominio", cd_cond.zfill(2))
        elif cd_lote is None or cd_lote.strip() == "":
            n_via += 1
            chave = ("via_acesso", str(n_via))
        else:
            chave = ("fiscal", cd_lote.zfill(4))
        grupos.setdefault(chave, []).append(feat)

    lotes, avisos = [], []
    for (tipo, cod), feats in sorted(grupos.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        props = [x.get("properties", {}) for x in feats]
        geoms = [geometria_utm(x["geometry"]) for x in feats if x.get("geometry")]
        if not geoms:
            avisos.append(f"Lote {tipo} {cod} sem geometria no GeoSampa; ignorado na base MDC.")
            continue
        geom = unary_union(geoms)
        p0 = props[0]
        lote_avisos = []

        area_iptu = None
        if tipo != "via_acesso":
            valores = sorted({v for v in (_num(p.get(f["campo_area_terreno"])) for p in props) if v is not None})
            if len(valores) == 1:
                area_iptu = valores[0]
            elif len(valores) > 1:
                # Unidades de condomínio repetem a área total do terreno; valores diferentes
                # indicam cadastro inconsistente. Usa o maior e sinaliza.
                area_iptu = valores[-1]
                lote_avisos.append(
                    f"Registros IPTU com áreas de terreno diferentes ({', '.join(f'{v:.0f}' for v in valores)} m²); "
                    f"usado o maior. Conferir no cadastro.")

            else:
                lote_avisos.append("Sem área de terreno no IPTU: fica fora da soma IPTU.")

        if tipo == "condominio":
            rotulo, sql = f"CD {cod}", None
            enderecos = sorted({_endereco(p, f) for p in props} - {None})
            endereco = enderecos[0] if enderecos else None
        elif tipo == "fiscal":
            rotulo = f"F{cod}"
            sql = formatar_sql(setor, quadra, cod, p0.get(f["campo_digito"]))
            endereco = _endereco(p0, f)
        else:
            rotulo, sql, endereco = f"VIA {cod}", None, _endereco(p0, f)
            lote_avisos.append("Sem SQL (via de acesso ou área comum): conta na área MDC da quadra, não no IPTU.")

        lotes.append(Lote(
            id=rotulo, tipo=tipo, geom=geom, area_iptu=area_iptu, sql=sql,
            cd_lote=None if tipo != "fiscal" else cod,
            cd_condominio=cod if tipo == "condominio" else None,
            endereco=endereco, tipo_uso=p0.get(f["campo_tipo_uso"]),
            area_construida=_num(p0.get(f["campo_area_construida"])),
            n_registros=len(feats), avisos=lote_avisos))
    return lotes, avisos


def _endereco(p: dict, f: dict) -> str | None:
    log = p.get(f["campo_logradouro"])
    num = p.get(f["campo_numero"])
    if not log:
        return None
    log = " ".join(str(log).split()).title()
    return f"{log}, {int(num) if str(num).isdigit() else num}" if num not in (None, "", 0, "0") else log


def montar_edificacoes(features: list[dict]) -> list[Edificacao]:
    f = camadas()["edificacao"]
    out = []
    for i, feat in enumerate(features):
        if not feat.get("geometry"):
            continue
        h = _num(feat.get("properties", {}).get(f["campo_altura"]))
        out.append(Edificacao(id=str(feat.get("id") or f"edif-{i}"),
                              geom=geometria_utm(feat["geometry"]),
                              altura_mdc=h if h is not None and h > 0 else None))
    return out


def atribuir_edificacoes(lotes: list[Lote], edificacoes: list[Edificacao],
                         geom_quadra: BaseGeometry | None) -> dict:
    """Atribui cada edificação a exatamente um lote pelo ponto interno.
    Edificações cujo ponto interno cai fora da quadra são descartadas (vieram do BBOX)."""
    fora, sem_lote, multiplos = 0, [], []
    for e in edificacoes:
        pt = e.geom.representative_point()
        if geom_quadra is not None and not geom_quadra.buffer(0.5).contains(pt):
            fora += 1
            continue
        donos = [l for l in lotes if l.geom.buffer(0.01).contains(pt)]
        if not donos:
            sem_lote.append(e.id)
            continue
        if len(donos) > 1:
            donos.sort(key=lambda l: l.geom.intersection(e.geom).area, reverse=True)
            multiplos.append(e.id)
            e.avisos.append(f"Ponto interno em {len(donos)} lotes sobrepostos; atribuída a {donos[0].id}.")
        e.lote_id = donos[0].id
        donos[0].edificacoes.append(e)
    return {
        "fora_da_quadra": fora,
        "sem_lote": sem_lote,
        "em_lotes_sobrepostos": multiplos,
        "lotes_sem_edificacao": [l.id for l in lotes if not l.edificacoes],
    }


def geojson(geom: BaseGeometry) -> dict:
    return mapping(geom)
