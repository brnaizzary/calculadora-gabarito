"""Alturas legais pelo LiDAR 2020 da PMSP (nuvens de pontos MDS e MDT do GeoSampa).

Altura legal (Lei 18.081/2024, art. 1º, III) = Z da laje de cobertura − Z do térreo.

- Z laje: pontos classe 6 (edificação) do MDS no LOTE inteiro (recuado 1 m das divisas; a
  pegada MDC é de 2007 e não vê obras posteriores). Superfície de topo = maior Z por célula
  de 1 m (some com as fachadas); as células são agrupadas em níveis (faixas de 0,5 m com
  área relevante). Partindo do nível mais alto: um volume que assenta sobre um nível maior,
  até 8 m abaixo dele, é candidato a ático (COE, art. 3º, VI: casa de máquinas, piso técnico
  de elevadores, equipamentos, caixa d'água e circulação vertical). Se a área dele for até
  40% da planta do nível de baixo, é excluído (ático); de 40% a 80%, pode ser cobertura
  habitável e a altura fica "a confirmar" entre os dois níveis; acima de 80% é o próprio
  pavimento (recuo pequeno, platibanda). Esses limites são regra técnica do app:
  a lei define o ático pelo uso, sem limite de área. O topo (com barrilete) é o percentil 99.
- Z térreo: nível médio da testada (Res. CEUSO 160/2025) = (maior + menor cota dos
  vértices da testada) ÷ 2. Cota de cada vértice = mediana dos pontos do MDT a até 4 m,
  do lado de fora da quadra (calçada).
- Faixa (art. 61): desnível ≤ 2 m → térreo entre o nível médio e +1 m; desnível > 2 m →
  térreo entre a menor e a maior cota da testada.
"""
from __future__ import annotations

import io
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import requests
from shapely import contains_xy
from shapely.geometry import MultiPoint, Point
from shapely.geometry.base import BaseGeometry

from . import geosampa
from .calculo import AlturaLote
from .config import camadas, pasta_cache
from .modelo import Lote


CACHE = pasta_cache() / "lidar"
METODO = ("LiDAR 2020 (PMSP/GeoSampa): laje = nível mais alto da cobertura no lote, excluídos os volumes "
          "menores assentados sobre ela (ático, casa de máquinas, caixa d'água); térreo = nível médio da testada "
          "pelo MDT (calçada). Precisão estimada ±3 m.")
PARAMS_COBERTURA = {
    "celula_m": 1.0,             # célula da superfície de topo
    "faixa_m": 0.5,              # largura das faixas de cota
    "celulas_min_faixa": 4,      # faixa com menos células é ruído (fachada, antena)
    "nivel_area_min_m2": 20.0,   # nível menor que isso é ignorado
    "atico_desnivel_max_m": 8.0, # acima disso o volume é outro corpo do prédio, não ático
    "atico_razao_area_max": 0.4, # até 40% da planta do nível de baixo: ático (excluído)
    "atico_razao_area_confirmar_max": 0.8,  # de 40% a 80%: "a confirmar"; acima: é o próprio pavimento
    "atico_contato_min": 0.45,   # fração do perímetro do volume que encosta na laje de baixo
}


# ------------------------------------------------------------------ download

def folhas(geom_q: BaseGeometry, usar_cache: bool = True) -> tuple[list[str], geosampa.FonteResultado]:
    c = camadas()["lidar"]
    x0, y0, x1, y1 = geom_q.buffer(30).bounds
    r = geosampa.get_feature("Articulação LiDAR 2020 (quadricula_folha_mdt_mds_2020)", c["typeName_folhas"],
                             f"BBOX({c['campo_geometria']},{x0:.2f},{y0:.2f},{x1:.2f},{y1:.2f})", usar_cache)
    return sorted({f["properties"][c["campo_folha"]] for f in r.features}) if r.ok else [], r


def _baixar(tipo: str, folha: str) -> tuple[Path | None, str | None, str]:
    """Baixa e extrai a folha (só o .laz, nunca caminhos do zip). Devolve (arquivo, erro, data)."""
    c = camadas()["lidar"]
    pasta = CACHE / tipo
    pasta.mkdir(parents=True, exist_ok=True)
    destino = pasta / f"{folha}.laz"
    if destino.exists():
        return destino, None, datetime.fromtimestamp(destino.stat().st_mtime, timezone.utc).isoformat(timespec="seconds")
    url = c["url_download"].format(pasta=c["pastas"][tipo], folha=folha)
    erro = None
    for tentativa in range(3):
        try:
            r = requests.get(url, timeout=c.get("timeout_s", 300))
            r.raise_for_status()
            if not r.content.startswith(b"PK"):
                raise ValueError("o servidor não devolveu um arquivo .zip (folha inexistente ou portal fora do ar)")
            with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                membros = [m for m in z.infolist() if m.filename.lower().endswith(".laz")]
                if not membros:
                    raise ValueError("zip sem arquivo .laz")
                tmp = destino.with_suffix(".tmp")
                tmp.write_bytes(z.read(membros[0]))
                tmp.replace(destino)
            return destino, None, datetime.now(timezone.utc).isoformat(timespec="seconds")
        except (requests.RequestException, ValueError, zipfile.BadZipFile) as e:
            erro = f"{type(e).__name__}: {e}"
            time.sleep(2 ** tentativa)
    return None, f"Falha ao baixar {tipo} {folha} ({erro}).", datetime.now(timezone.utc).isoformat(timespec="seconds")


def _ler_recorte(arq: Path, tipo: str, caixa: tuple) -> np.ndarray:
    """Pontos da folha dentro da caixa (x0, y0, x1, y1): MDS com a classe, MDT só x, y, z.
    A versão HTML troca esta função pela leitura no navegador (laz-perf)."""
    import laspy
    x0, y0, x1, y1 = caixa
    las = laspy.read(arq)
    x, y, z = np.asarray(las.x), np.asarray(las.y), np.asarray(las.z)
    m = (x >= x0) & (x <= x1) & (y >= y0) & (y <= y1)
    if tipo == "MDS":
        return np.c_[x[m], y[m], z[m], np.asarray(las.classification)[m]]
    return np.c_[x[m], y[m], z[m]]


def _pontos_folha(tipo: str, folha: str, caixa: tuple) -> tuple[np.ndarray | None, str | None, str]:
    """Baixa (ou usa o cache) e recorta uma folha. Devolve (pontos, erro, data)."""
    arq, erro, data = _baixar(tipo, folha)
    if erro:
        return None, erro, data
    return _ler_recorte(arq, tipo, caixa), None, data


def nuvens(geom_q: BaseGeometry, setor: str, quadra: str, usar_cache: bool = True):
    """Pontos MDS (x, y, z, classe) e MDT (x, y, z) recortados à quadra + 30 m, com cache por quadra."""
    c = camadas()["lidar"]
    recorte = CACHE / f"recorte_{setor}_{quadra}.npz"
    lista, r_folhas = folhas(geom_q, usar_cache)
    fontes = [r_folhas]
    if usar_cache and recorte.exists():
        dados = np.load(recorte)
        data = datetime.fromtimestamp(recorte.stat().st_mtime, timezone.utc).isoformat(timespec="seconds")
        url = c["url_download"].format(pasta="{MDS_2020|MDT_2020}", folha="{" + "|".join(lista) + "}")
        fontes.append(geosampa.FonteResultado(f"LiDAR 2020 – folhas {', '.join(lista)}", url,
                                              data, True, [{}] * len(dados["mds"])))
        return dados["mds"], dados["mdt"], fontes
    if not lista:
        fontes.append(geosampa.FonteResultado("LiDAR 2020", None, None, erro="Nenhuma folha LiDAR cobre a quadra."))
        return None, None, fontes

    tarefas = [(t, f) for t in ("MDS", "MDT") for f in lista]
    caixa = geom_q.buffer(30).bounds
    with ThreadPoolExecutor(max_workers=4) as ex:
        res = dict(zip(tarefas, ex.map(lambda tf: _pontos_folha(*tf, caixa), tarefas)))
    erros = [e for _, e, _ in res.values() if e]
    data = max(d for _, _, d in res.values())
    url = c["url_download"].format(pasta="{MDS_2020|MDT_2020}", folha="{" + "|".join(lista) + "}")
    if erros:
        fontes.append(geosampa.FonteResultado("LiDAR 2020", url, data, erro=" ".join(erros)))
        return None, None, fontes

    partes = {"MDS": [], "MDT": []}
    for (tipo, _), (pts, _, _) in res.items():
        partes[tipo].append(pts)
    mds, mdt = np.vstack(partes["MDS"]), np.vstack(partes["MDT"])
    np.savez_compressed(recorte, mds=mds, mdt=mdt)
    fontes.append(geosampa.FonteResultado(f"LiDAR 2020 – folhas {', '.join(lista)}", url, data, False, [{}] * len(mds)))
    return mds, mdt, fontes


# ------------------------------------------------------------------ medições

def _topo(pts: np.ndarray, c: float) -> tuple[np.ndarray, np.ndarray]:
    """Maior Z de cada célula: (índices i, j das células, Z de topo)."""
    ij = np.floor(pts[:, :2] / c).astype(np.int64)
    ordem = np.lexsort((pts[:, 2], ij[:, 1], ij[:, 0]))
    ij, z = ij[ordem], pts[ordem, 2]
    ultimo = np.r_[np.any(ij[1:] != ij[:-1], axis=1), True]
    return ij[ultimo], z[ultimo]


def niveis_cobertura(regiao: BaseGeometry, mds: np.ndarray, classe: int = 6,
                     p: dict | None = None) -> tuple[list[dict], np.ndarray, dict]:
    """Níveis da superfície de topo das edificações na região, do mais baixo ao mais alto.

    Cada nível: cota mediana, área (m², células de 1 m) e as células. Devolve também as cotas
    de topo das células de edificação (para o percentil 99) e a superfície de topo de TODAS as
    classes (célula -> Z): no MDS 2020 parte das lajes vem como "não classificado" ou
    vegetação, e é ela que mostra a laje em volta de um ático.
    """
    p = {**PARAMS_COBERTURA, **(p or {})}
    dentro = contains_xy(regiao, mds[:, 0], mds[:, 1])
    m = dentro & (mds[:, 3] == classe)
    if m.sum() < 20:
        return [], np.empty(0), {}
    c = p["celula_m"]
    ij_t, z_t = _topo(mds[dentro & (mds[:, 3] != 7)], c)  # 7 = ruído
    superficie = dict(zip(_chave(ij_t).tolist(), z_t.tolist()))
    ij_e, zc = _topo(mds[m], c)
    cel = (ij_e + 0.5) * c

    f = p["faixa_m"]
    faixa = np.floor(zc / f).astype(np.int64)
    f0 = faixa.min()
    contagem = np.bincount((faixa - f0).astype(np.intp))  # intp: no navegador (WebAssembly) o numpy é 32 bits
    densa = contagem >= p["celulas_min_faixa"]
    niveis, k = [], 0
    while k < len(densa):
        if not densa[k]:
            k += 1
            continue
        fim = k
        while fim + 1 < len(densa) and (densa[fim + 1] or (fim + 2 < len(densa) and densa[fim + 2])):
            fim += 1  # tolera uma faixa rala entre duas densas (laje inclinada, platibanda)
        sel = (faixa - f0 >= k) & (faixa - f0 <= fim)
        area = float(sel.sum() * c * c)
        if area >= p["nivel_area_min_m2"]:
            niveis.append({"z": float(np.median(zc[sel])), "z_min": float(zc[sel].min()),
                           "z_max": float(zc[sel].max()), "area_m2": area, "xy": cel[sel],
                           "chaves": set(_chave(ij_e[sel]).tolist())})
        k = fim + 1
    return niveis, zc, superficie


def _chave(ij: np.ndarray) -> np.ndarray:
    return ij[:, 0] * 10_000_019 + ij[:, 1]


def _na_faixa(z: float | None, nivel: dict) -> bool:
    return z is not None and nivel["z_min"] - 0.5 <= z <= nivel["z_max"] + 0.5


def _contato(alto: dict, baixo: dict, superficie: dict) -> float:
    """Fração do perímetro do volume `alto` (células vizinhas, fora dele) cuja superfície de topo
    está na cota do nível `baixo`.

    Ático no meio da laje: ~100%; recuado em dois lados: ~50%; torre ao lado de uma ala baixa: ~25%.
    """
    vizinhos = [k + d for k in alto["chaves"] for d in (1, -1, 10_000_019, -10_000_019)]
    fora = [v for v in vizinhos if v not in alto["chaves"]]
    return sum(_na_faixa(superficie.get(v), baixo) for v in fora) / len(fora) if fora else 0.0


def _area_laje(baixo: dict, alto: dict, superficie: dict, celula_m: float) -> float:
    """Área da laje `baixo` vista de cima, por todas as classes, dentro do contorno de laje + volume."""
    pts = np.vstack([baixo["xy"], alto["xy"]])
    contorno = MultiPoint(pts).convex_hull.buffer(celula_m)
    chaves = np.fromiter(superficie.keys(), np.int64, len(superficie))
    zs = np.fromiter(superficie.values(), float, len(superficie))
    na_faixa = (zs >= baixo["z_min"] - 0.5) & (zs <= baixo["z_max"] + 0.5)
    i, j = np.divmod(chaves[na_faixa], 10_000_019)
    n = contains_xy(contorno, (i + 0.5) * celula_m, (j + 0.5) * celula_m).sum()
    return max(float(n) * celula_m ** 2, baixo["area_m2"])


def escolher_cobertura(niveis: list[dict], superficie: dict, p: dict | None = None) -> dict:
    """Cobertura legal (Lei 16.402/2016, art. 1º, par. único, III): nível mais alto, sem ático.

    Desce a partir do nível mais alto. Se há, até 8 m abaixo, uma laje maior que ele (ou em que
    ele encosta em ≥ 45% do perímetro), é volume sobre aquela laje: até 40% da planta (laje +
    volume) é ático (excluído, e
    segue descendo); de 40% a 80% pode ser cobertura habitável e a altura fica "a confirmar"
    entre os dois níveis; acima de 80% é o próprio pavimento (recuo pequeno ou platibanda).
    """
    p = {**PARAMS_COBERTURA, **(p or {})}
    papeis = {id(n): "abaixo da cobertura" for n in niveis}
    i, z_min, motivo, acima = len(niveis) - 1, None, None, 0.0
    while True:
        alto = niveis[i]
        area_alto = alto["area_m2"] + acima  # volumes já excluídos assentam sobre ele
        base = None
        for j in range(i - 1, -1, -1):
            if alto["z"] - niveis[j]["z"] > p["atico_desnivel_max_m"]:
                break
            # Laje de baixo maior que o volume (caso comum; a classificação do MDS nas coberturas é
            # irregular demais para depender só do contato) ou volume recuado encostado nela.
            if niveis[j]["area_m2"] > area_alto or _contato(alto, niveis[j], superficie) >= p["atico_contato_min"]:
                base = j
                break
        if base is not None:
            planta = (_area_laje(niveis[base], alto, superficie, p["celula_m"])
                      + sum(n["area_m2"] for n in niveis[base + 1:i]) + area_alto)
            razao = area_alto / planta
        if base is None or razao > p["atico_razao_area_confirmar_max"]:
            papeis[id(alto)] = "cobertura"
            break
        if razao <= p["atico_razao_area_max"]:
            papeis[id(alto)] = f"excluído: ático/casa de máquinas/caixa d'água ({razao:.0%} da planta)"
            for j in range(base + 1, i):
                papeis[id(niveis[j])] = "excluído: volume intermediário do ático"
            acima = planta - _area_laje(niveis[base], alto, superficie, p["celula_m"])
            i = base
            continue
        papeis[id(alto)] = f"cobertura a confirmar: ático ou cobertura habitável ({razao:.0%} da planta)"
        papeis[id(niveis[base])] = "laje sob o volume (mínimo da faixa)"
        z_min = niveis[base]["z"]
        motivo = (f"Volume de {area_alto:.0f} m² a {alto['z'] - z_min:.1f} m acima da laje de baixo "
                  f"({razao:.0%} da planta): pode ser ático (excluído do gabarito) ou cobertura habitável (incluída). "
                  "Faixa entre os dois níveis; confirmar o uso com o Alvará.")
        break
    cob = niveis[i]
    return {"z_laje": cob["z"], "z_laje_min": z_min, "a_confirmar_motivo": motivo,
            "area_cobertura_m2": cob["area_m2"], "xy_cobertura": cob["xy"],
            "niveis": [{"z": round(n["z"], 2), "area_m2": round(n["area_m2"]), "papel": papeis[id(n)]}
                       for n in niveis]}


def cota_laje(regiao: BaseGeometry, mds: np.ndarray, classe: int = 6, p: dict | None = None) -> dict | None:
    niveis, zc, superficie = niveis_cobertura(regiao, mds, classe, p)
    if not niveis:
        return None
    c = escolher_cobertura(niveis, superficie, p)
    return {**c, "z_topo": float(np.percentile(zc, 99)), "n_pontos": int(len(zc))}


def cotas_testada(lote: Lote, geom_q: BaseGeometry, mdt: np.ndarray) -> dict:
    """Cotas dos vértices da testada (vértices do lote sobre o perímetro da quadra)."""
    borda = geom_q.boundary
    aneis = [lote.geom.exterior] if lote.geom.geom_type == "Polygon" else [p.exterior for p in lote.geom.geoms]
    vertices = [Point(c) for a in aneis for c in a.coords[:-1] if Point(c).distance(borda) < 0.5]
    fora = ~contains_xy(geom_q, mdt[:, 0], mdt[:, 1])
    cotas, aviso = [], None
    for v in vertices:
        d = np.hypot(mdt[:, 0] - v.x, mdt[:, 1] - v.y)
        sel = (d < 4) & fora
        if sel.sum() < 3:
            sel = d < 4
        if sel.sum():
            cotas.append(float(np.median(mdt[sel, 2])))
    if not cotas:
        # Lote sem frente para via pública (ex.: vila interna): usa o terreno do próprio lote.
        sel = contains_xy(lote.geom.buffer(2), mdt[:, 0], mdt[:, 1])
        if sel.sum() >= 3:
            cotas = [float(np.percentile(mdt[sel, 2], 5)), float(np.percentile(mdt[sel, 2], 95))]
            aviso = "Lote sem testada para a via pública; cota do térreo estimada pelo terreno do próprio lote."
    if not cotas:
        return {"ok": False, "aviso": "Sem pontos de terreno (MDT) próximos do lote."}
    mx, mn = max(cotas), min(cotas)
    return {"ok": True, "n_vertices": len(cotas), "maior": mx, "menor": mn,
            "nivel_medio": (mx + mn) / 2, "desnivel": mx - mn, "aviso": aviso}


def declividade_pct(lote: Lote, mdt: np.ndarray) -> float | None:
    """Declividade média do terreno do lote (plano ajustado aos pontos do MDT), em %."""
    sel = contains_xy(lote.geom, mdt[:, 0], mdt[:, 1])
    if sel.sum() < 20:
        return None
    p = mdt[sel]
    if min(np.ptp(p[:, 0]), np.ptp(p[:, 1])) < 8:  # amostra estreita demais para um plano confiável
        return None
    A = np.c_[p[:, 0] - p[:, 0].mean(), p[:, 1] - p[:, 1].mean(), np.ones(len(p))]
    (a, b, _), *_ = np.linalg.lstsq(A, p[:, 2], rcond=None)
    return float(np.hypot(a, b) * 100)


def altura_lidar(lote: Lote, geom_q: BaseGeometry, mds: np.ndarray, mdt: np.ndarray,
                 p: dict | None = None) -> tuple[AlturaLote, dict]:
    """Altura legal da edificação mais alta do lote, com faixa do art. 61.

    Mede sempre pelo LiDAR, no lote inteiro, mesmo sem edificação no MDC 2007 (prédio novo).
    """
    p = {**PARAMS_COBERTURA, **(p or {})}
    extra = {"declividade_pct": declividade_pct(lote, mdt)}
    h_mdc = lote.altura_mdc_max
    if lote.tipo == "via_acesso":
        return AlturaLote(None, None, None, "lidar"), extra

    regiao = lote.geom.buffer(-1.0)  # 1 m das divisas: evita beiral e fachada do vizinho
    if regiao.is_empty or regiao.area < 0.3 * lote.geom.area:
        regiao = lote.geom
    c = cota_laje(regiao, mds, p=p)
    t = cotas_testada(lote, geom_q, mdt)
    if not lote.edificacoes:
        # Edificação ausente no MDC 2007: só conta se a cobertura for de um prédio de verdade.
        if c is None or not t["ok"] or c["z_laje"] - t["nivel_medio"] < p.get("nova_altura_min_m", 3.0) \
                or c["area_cobertura_m2"] < p.get("nova_area_min_m2", 30.0):
            return AlturaLote(None, None, None, "lidar"), extra
        extra["pegada_nova"] = MultiPoint(c["xy_cobertura"]).convex_hull.buffer(p["celula_m"] / 2)

    if not t["ok"]:
        return AlturaLote(None, None, None, "lidar", altura_mdc=h_mdc, avisos=[t["aviso"]]), extra
    extra["testada"] = t
    if c is None:
        return AlturaLote(None, None, None, "lidar", altura_mdc=h_mdc,
                          avisos=["Poucos pontos LiDAR de edificação sobre o lote; sem medição."]), extra
    extra["cobertura"] = {k: v for k, v in c.items() if k != "xy_cobertura"}

    zl, nm = c["z_laje"], t["nivel_medio"]
    central = zl - nm
    if t["desnivel"] <= 2:
        minima, maxima = zl - (nm + 1), central
    else:
        minima, maxima = zl - t["maior"], zl - t["menor"]
    avisos = [a for a in [t.get("aviso")] if a]
    if t["desnivel"] > 2:
        avisos.append(f"Desnível da testada de {t['desnivel']:.1f} m (> 2 m): térreo pode estar em qualquer cota "
                      "intermediária (art. 61, §§1º e 2º); mostrada a faixa.")
    if c["z_laje_min"] is not None:
        minima = min(minima, c["z_laje_min"] - (t["maior"] if t["desnivel"] > 2 else nm + 1))
        avisos.append(c["a_confirmar_motivo"])
    if not (0 < central < 300):
        return AlturaLote(None, None, None, "lidar", altura_mdc=h_mdc,
                          avisos=[f"Medição LiDAR fora do plausível ({central:.1f} m); sem medição."]), extra
    if "pegada_nova" in extra:
        avisos.append("Edificação ausente no MDC 2007 e presente no LiDAR 2020: obra posterior a 2007.")
    elif h_mdc is not None and central - h_mdc > p.get("obra_posterior_dif_m", 10.0):
        avisos.append(f"LiDAR 2020 {central - h_mdc:.0f} m acima do MDC 2007 ({h_mdc:.1f} m): provável obra ou "
                      "ampliação posterior a 2007.")
    return AlturaLote(central, minima, maxima, "lidar", altura_topo=c["z_topo"] - nm,
                      altura_mdc=h_mdc, avisos=avisos), extra
