"""Relatório técnico em PDF (A4, até 4 páginas), gerado a partir do resultado de pipeline.analisar.

Página 1 – Conclusão · Página 2 – Quadra via MDC · Página 3 – Quadra via IPTU ·
Página 4 – Base legal e base de cálculo. Todo texto vem dos dados; nada é fixo por quadra.
"""
from __future__ import annotations

import base64
from datetime import datetime, timezone
from html import escape
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "static"
FONTE_ALT = {"mdc": "MDC 2007", "lidar": "LiDAR 2020", "3d_tiles": "Google 3D", "alvara": "Alvará"}
SIT = {"sim": "Sim", "nao": "Não", "a_confirmar": "A confirmar", "sem_edificacao": "Sem edificação",
       "sem_medicao": "Sem medição"}


def n(v, casas=0, suf=""):
    if v is None:
        return "—"
    return f"{v:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".") + suf


def pct(v):
    return n(v, 1, "%")


def _faixa_pct(r: dict) -> str:
    i, m = r["bases"]["iptu"]["pct_lei"], r["bases"]["mdc"]["pct_lei"]
    if i is None or m is None:
        return pct(i if m is None else m)
    lo, hi = sorted([(m, "MDC"), (i, "IPTU")])
    return pct(lo[0]) if abs(lo[0] - hi[0]) < 0.05 else f"entre {pct(lo[0])} ({lo[1]}) e {pct(hi[0])} ({hi[1]})"


def texto_conclusao(r: dict) -> list[str]:
    """Até 3 frases didáticas, geradas a partir do resultado."""
    id_, p = r["identificacao"], r["parametros"]
    q = f"{id_['setor']}-{id_['quadra']}"
    g = n(p["gabarito_m"], 1).replace(",0", "")
    faixa = _faixa_pct(r)
    acima = [l["id"] for l in r["lotes"] if l["situacao"] == "sim"]
    conf = [l["id"] for l in r["lotes"] if l["situacao"] == "a_confirmar"]
    v = r["veredito"]
    if v == "SIM":
        f1 = f"A quadra {q} atende à exceção de gabarito. {faixa[0].upper() + faixa[1:]} da área dos lotes tem prédios acima de {g} m, e a lei exige mais de 50%."
    elif v == "NÃO":
        f1 = f"A quadra {q} não atende à exceção de gabarito. Apenas {faixa} da área dos lotes tem prédios acima de {g} m, e a lei exige mais de 50%."
    elif v == "A CONFIRMAR":
        motivo = r.get("nota_veredito") or "O resultado muda conforme os prédios com altura a menos de 3 m do gabarito."
        f1 = f"O resultado da quadra {q} depende de confirmação: {faixa} da área dos lotes tem prédios acima de {g} m. {motivo}"
    else:
        f1 = f"Não foi possível concluir a análise da quadra {q}: faltaram dados das fontes."
    frases = [f1]
    if acima:
        f2 = f"Prédios acima de {g} m: {', '.join(acima)}."
        if conf:
            f2 += f" A confirmar com Alvará: {', '.join(conf)}."
        frases.append(f2)
    elif conf:
        frases.append(f"Nenhum prédio está claramente acima de {g} m; a confirmar com Alvará: {', '.join(conf)}.")
    if p.get("ilustrativo"):
        z = id_["zona"].get("sigla") or "da quadra"
        if id_["zona"].get("sem_limite"):
            frases.append(f"A zona {z} não tem gabarito máximo no Quadro 3; o teste com {g} m é apenas ilustrativo.")
        elif id_["zona"].get("sigla"):
            frases.append(f"A zona {z} está fora do escopo do app (ZC e ZM); o teste com {g} m é apenas ilustrativo.")
        else:
            frases.append(f"A zona não foi identificada; o gabarito de {g} m é uma referência a validar.")
    return frases[:3]


def _logo() -> str:
    arq = STATIC / "logo-ryazbek.png"
    return "data:image/png;base64," + base64.b64encode(arq.read_bytes()).decode() if arq.exists() else ""


def _ruas(r: dict) -> list[str]:
    return sorted({e.split(",")[0].strip() for e in r["identificacao"]["enderecos"]})


CSS = """
@page { size: A4; margin: 14mm 14mm 16mm; @bottom-left { content: "Indicativo técnico; não substitui consulta à SMUL nem análise do COMAER/DECEA."; font-size: 7pt; color: #667085; }
        @bottom-right { content: "Página " counter(page) " de " counter(pages); font-size: 7pt; color: #667085; } }
* { box-sizing: border-box; }
body { font-family: "DejaVu Sans", "Segoe UI", Helvetica, Arial, sans-serif; font-size: 9pt; color: #1c2430; line-height: 1.35; }
.pagina { page-break-after: always; }
.pagina:last-child { page-break-after: auto; }
.topo { display: flex; justify-content: space-between; align-items: center; border-bottom: 2.5pt solid #cd2d31; padding-bottom: 5pt; margin-bottom: 9pt; }
.topo img { height: 15pt; }
.topo .t { text-align: right; font-size: 8pt; color: #475467; }
h1 { font-size: 14pt; margin: 0 0 6pt; }
h2 { font-size: 11pt; margin: 10pt 0 4pt; }
.pergunta { font-size: 8pt; text-transform: uppercase; letter-spacing: .06em; color: #667085; margin: 0; }
.veredito { border: 2pt solid #3d4a5c; border-radius: 6pt; padding: 9pt 12pt; margin: 6pt 0 10pt; }
.veredito.sim { border-color: #b42318; } .veredito.conf { border-color: #8a6100; }
.colunas { columns: 2; column-gap: 14pt; }
.colunas h2 { margin-top: 6pt; }
.veredito .v { font-size: 17pt; font-weight: 800; margin: 0 0 4pt; }
.veredito.sim .v { color: #b42318; } .veredito.nao .v { color: #3d4a5c; } .veredito.conf .v { color: #8a6100; }
.veredito p { margin: 3pt 0; font-size: 10pt; }
table { border-collapse: collapse; width: 100%; }
th, td { border-bottom: .5pt solid #d0d5dd; padding: 3pt 4pt; text-align: left; vertical-align: top; }
th { background: #f2f4f7; font-weight: 700; }
td.n, th.n { text-align: right; }
.resumo td.n { font-weight: 700; font-size: 10pt; }
.grade { display: flex; gap: 10pt; }
.grade > div { flex: 1; }
.caixa { border: .5pt solid #d0d5dd; border-radius: 4pt; padding: 6pt 8pt; margin-bottom: 8pt; }
.mini { font-size: 7.5pt; color: #475467; }
.mapa svg { width: 100%; height: auto; max-height: 175mm; border: .5pt solid #d0d5dd; }
.compacta th, .compacta td { font-size: 7pt; padding: 1.6pt 3pt; }
.legal p { margin: 0 0 3pt; font-size: 7.6pt; }
.sim { color: #b42318; font-weight: 700; } .conf { color: #8a6100; font-weight: 700; } .ok { color: #1e7a46; font-weight: 700; }
.alerta { font-size: 8pt; margin: 2pt 0; padding-left: 8pt; border-left: 2pt solid #8a6100; }
.div { color: #c4320a; font-weight: 700; }
ul { margin: 2pt 0 4pt; padding-left: 13pt; } li { margin-bottom: 1.5pt; }
"""


def _topo(r: dict, titulo: str) -> str:
    id_ = r["identificacao"]
    return (f'<div class="topo"><img src="{_logo()}" alt="R.Yazbek"><div class="t">Quebra de gabarito · Quadra '
            f'{id_["setor"]}-{id_["quadra"]}<br>{escape(titulo)}</div></div>')


def _pagina1(r: dict, gerado: str) -> str:
    id_, p, b = r["identificacao"], r["parametros"], r["bases"]
    cls = {"SIM": "sim", "NÃO": "nao"}.get(r["veredito"], "conf")
    frases = "".join(f"<p>{escape(f)}</p>" for f in texto_conclusao(r))
    g = n(p["gabarito_m"], 1).replace(",0", "")
    z = id_["zona"]
    zona = ("informado" if z.get("gabarito_alterado") else "zona não identificada" if not z.get("sigla")
            else f"{z['sigla']}, ilustrativo" if z.get("sem_limite") or z.get("gabarito_m") is None else z["sigla"])
    acima = f"Área edificada &gt; {g} m [{escape(zona)}]"

    def lei(k):
        cls = {"SIM": "ok", "NÃO": "sim"}.get(b[k]["veredito_lei"], "conf")  # verde passa; vermelho não passa
        return f'<span class="{cls}">{pct(b[k]["pct_lei"])} · {b[k]["veredito_lei"]}</span>'
    linhas = [
        ("Área da quadra", f'{n(b["iptu"]["area_quadra"], 2)} m²', f'{n(b["mdc"]["area_quadra"], 2)} m²'),
        ("Área edificada", f'{n(b["iptu"]["area_edificada"], 2)} m²', f'{n(b["mdc"]["area_edificada"], 2)} m²'),
        ("% Área edificada", pct(b["iptu"]["pct_edificada"]), pct(b["mdc"]["pct_edificada"])),
        (acima, f'{n(b["iptu"]["area_acima"], 2)} m²', f'{n(b["mdc"]["area_acima"], 2)} m²'),
        (f"% {acima} (art. 60, II) – exige &gt; 50%", lei("iptu"), lei("mdc")),
    ]
    tab = "".join(f"<tr><td>{a}</td><td class='n'>{c1}</td><td class='n'>{c2}</td></tr>" for a, c1, c2 in linhas)
    sens = [f"Base {k.upper()}: tratando os casos a confirmar como Sim, o veredito vira {v['sensibilidade']['a_confirmar_como_sim']}."
            for k, v in b.items() if v["sensibilidade"]["muda"]]
    fontes = "".join(
        f"<li>{escape(f['nome'])}: " + (f"<span class='sim'>indisponível – {escape(f['erro'])}</span>" if f["erro"]
                                        else f"consultado em {escape(_data(f['consultado_em']))}") + "</li>"
        for f in r["fontes"])
    alertas = "".join(f"<p class='alerta'>{escape(a['texto'])}</p>" for a in r["alertas"]
                      if a["nivel"] in ("aviso", "destaque", "falha"))
    return f"""<section class="pagina">{_topo(r, "Conclusão")}
<p class="pergunta">Esta quadra permite verticalizar acima do gabarito?</p>
<div class="veredito {cls}"><p class="v">QUEBRA DE GABARITO: {escape(r['veredito'])}{' (ilustrativo)' if p['ilustrativo'] else ''}</p>{frases}</div>
<table class="resumo"><tr><th></th><th class="n">Via IPTU</th><th class="n">Via MDC</th></tr>{tab}</table>
{''.join(f"<p class='alerta'><b>{escape(s)}</b></p>" for s in sens)}
<div class="grade" style="margin-top:9pt">
<div class="caixa"><h2 style="margin-top:0">Identificação</h2>
<p>Setor <b>{id_['setor']}</b> · Quadra <b>{id_['quadra']}</b> · Distrito {escape((id_.get('distrito') or '—').title())}</p>
<p>Zona <b>{escape(z.get('sigla') or 'não identificada')}</b> (Lei 18.081/2024; {escape(z.get('origem') or 'predominante na quadra')}) · Gabarito usado: <b>{g} m</b>
{'(zona sem gabarito máximo; teste ilustrativo)' if z.get('sem_limite') else ('(fora do escopo ZC/ZM; teste ilustrativo)' if p['ilustrativo'] else '')}</p>
<p>Ruas que limitam a quadra: {escape(', '.join(_ruas(r)) or '—')}</p>
<p>Lote edificado: {escape(r['criterios_edificado'].get(p['criterio_edificado'], p['criterio_edificado']))}</p></div>
<div class="caixa"><h2 style="margin-top:0">Fontes e data</h2><p class="mini">Relatório gerado em {gerado}.</p><ul class="mini">{fontes}</ul></div>
</div>{alertas}</section>"""


def _data(iso: str | None) -> str:
    if not iso:
        return "—"
    try:
        return datetime.fromisoformat(iso).astimezone().strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return iso


def _pagina_mapa(r: dict, modo: str) -> str:
    g = n(r["parametros"]["gabarito_m"], 1).replace(",0", "")
    b = r["bases"][modo]
    if modo == "mdc":
        titulo, pergunta = "Quadra Fiscal via MDC", "Quais lotes têm prédios acima do gabarito, pela área do mapa (MDC)?"
        nota = (f"Áreas medidas nos polígonos de lote do Mapa Digital da Cidade (fórmula de Gauss). A área da quadra "
                f"({n(b['area_quadra'], 2)} m²) inclui lotes sem SQL, como vias de acesso.")
        extra = ""
    else:
        titulo, pergunta = "Quadra Fiscal via IPTU", "E pela área do cadastro fiscal (IPTU)? Onde as bases divergem?"
        nota = (f"Áreas do cadastro do IPTU (qt_area_terreno). A área da quadra ({n(b['area_quadra'], 2)} m²) soma só "
                "os lotes com SQL. Lotes hachurados têm diferença maior que 10% entre MDC e IPTU.")
        divs = sorted((l for l in r["lotes"] if l["divergencia_relevante"]), key=lambda l: -abs(l["diferenca_pct"]))
        extra = ("<p class='mini'><b>Divergências MDC × IPTU acima de 10%:</b> "
                 + "; ".join(f"{escape(l['id'])} {'+' if l['diferenca_pct'] > 0 else ''}{n(l['diferenca_pct'])}%"
                             f" ({n(l['area_iptu'])} → {n(l['area_mdc'])} m²)" for l in divs) + ".</p>") if divs else ""
    return f"""<section class="pagina">{_topo(r, titulo)}
<p class="pergunta">{pergunta}</p><h1>{titulo}</h1>
<div class="mapa">{r['mapas'].get(modo, '<p>Mapa indisponível.</p>')}</div>
<p class="mini">{nota} Rótulo de cada lote: código, altura legal da edificação mais alta e área. Lotes acima de {g} m:
{n(b['area_acima'], 2)} m² = {pct(b['pct_lei'])} da quadra.</p>{extra}</section>"""


def _pagina4(r: dict, max_linhas: int | None = None) -> str:
    t = r["texto_legal"]
    legal = "".join(f"<p>{escape(t[k])}</p>" for k in ("art60_caput", "art60_I", "art60_II", "art60_p1", "art60_p2",
                                                      "art1_III_18081", "art61", "ceuso_160") if k in t)
    g = r["parametros"]["gabarito_m"]
    rel = [l for l in r["lotes"] if l["n_edificacoes"] and (l["altura_legal"] or 0) >= 15]
    demais = len(r["lotes"]) - len(rel)
    rel.sort(key=lambda l: -(l["altura_legal"] or 0))
    if max_linhas is not None and len(rel) > max_linhas:
        demais += len(rel) - max_linhas
        rel = rel[:max_linhas]
    linhas = "".join(
        f"<tr><td>{escape(l['id'])}</td><td>{escape(l['endereco'] or '—')}</td><td class='n'>{n(l['area_iptu'])}</td>"
        f"<td class='n'>{n(l['area_mdc'])}</td><td class='n {'div' if l['divergencia_relevante'] else ''}'>"
        f"{'—' if l['diferenca_pct'] is None else n(l['diferenca_pct'], 0, '%')}</td><td class='n'>{n(l['altura_mdc'], 1)}</td>"
        f"<td class='n'>{n(l['altura_legal'], 1)}" + (f" ({n(l['altura_legal_min'], 1)}–{n(l['altura_legal_max'], 1)})"
                                                     if l['altura_legal_min'] != l['altura_legal_max'] else "") +
        f"</td><td class='{ {'sim': 'sim', 'a_confirmar': 'conf'}.get(l['situacao'], '') }'>{SIT[l['situacao']]}</td>"
        f"<td>{escape(l.get('referencia_altura') or FONTE_ALT.get(l['fonte_altura'], l['fonte_altura']))}</td></tr>" for l in rel)
    validacoes = "".join(
        f"<li>✓ {escape(v['nome'])}</li>" if v["ok"] and not v["nome"].startswith("Lotes sem")
        else f"<li>{'✓' if v['ok'] else ('?' if v['ok'] is None else '✗')} {escape(v['nome'])}: {escape(v['detalhe'])}</li>"
        for v in r["validacoes"])
    lim = "".join(f"<li>{escape(x)}</li>" for x in r["limitacoes"])
    conf = [l["id"] for l in r["lotes"] if l["situacao"] == "a_confirmar"]
    passos = ["Confirmar a zona e o gabarito do Quadro 3 vigente para o terreno.",
              "Consultar as restrições de altura do COMAER/DECEA (plano de proteção de aeródromo)."]
    if conf:
        passos.insert(0, f"Obter os Alvarás de {', '.join(conf)} (casos a menos de 3 m do gabarito) e lançar as alturas no app.")
    passos.append("Validar com a SMUL como a exceção do art. 60, II se aplica a prédios aprovados por leis anteriores.")
    return f"""<section class="pagina">{_topo(r, "Base legal e base de cálculo")}
<p class="pergunta">Como o resultado foi calculado e quais são os limites?</p>
<div class="grade"><div class="legal"><h2 style="margin-top:0">Base legal</h2>{legal}<p class="mini">{escape(t.get('_obs', ''))}</p></div>
<div><h2 style="margin-top:0">Fórmulas</h2>
<p class="mini"><b>% da lei</b> = Σ área dos lotes com edificação acima de {n(g, 1).replace(',0', '')} m ÷ área da quadra (art. 60, II e §1º: conta o lote inteiro). Exige mais de 50%.</p>
<p class="mini"><b>Altura legal</b> = cota da laje de cobertura − cota do térreo (Lei 18.081/2024, art. 1º, III), sem ático, casa de máquinas e caixa d'água.</p>
<p class="mini"><b>Térreo</b> = nível médio da testada = (maior + menor cota dos vértices) ÷ 2 (Res. CEUSO 160/2025). Faixa pelo art. 61: desnível ≤ 2 m, térreo até 1 m acima; &gt; 2 m, entre as cotas extremas.</p>
<p class="mini"><b>Critério interno</b> (secundário): ≥ 50% da quadra edificada e ≥ 50% da área edificada acima do gabarito.</p>
<p class="mini"><b>Método das alturas:</b> LiDAR 2020 da Prefeitura (≈10 pontos/m²): cobertura = nível mais alto do prédio no lote; volumes menores sobre ela (até 40% da área e até 8 m acima) são excluídos como ático, casa de máquinas ou caixa d'água, e maiores ficam "a confirmar" (podem ser cobertura habitável). Critério técnico do app: a lei define o ático pelo uso (COE, art. 3º, VI), sem limite de área. Térreo pelo MDT na calçada. Precisão ≈ ±3 m; casos a menos de 3 m do gabarito ficam "a confirmar". Alvará, quando informado, prevalece. Todos os lotes são medidos pelo LiDAR; o MDC (2007) só entra se faltar medição.</p></div></div>
<h2>Lotes com edificação de 15 m ou mais</h2>
<table class="compacta"><tr><th>Lote</th><th>Endereço</th><th class="n">Área IPTU</th><th class="n">Área MDC</th><th class="n">Dif.</th>
<th class="n">Alt. MDC</th><th class="n">Alt. legal (faixa)</th><th>&gt; gabarito</th><th>Fonte</th></tr>{linhas}</table>
<p class="mini">Demais {demais} lotes {'(os mais baixos) ' if max_linhas is not None else ''}fora desta tabela; lista completa na planilha .xlsx. Áreas em m², alturas em m.</p>
<div class="colunas"><h2>Conferências</h2><ul class="mini">{validacoes}</ul>
<h2>Limitações</h2><ul class="mini">{lim}</ul><h2>Próximos passos</h2><ul class="mini">{''.join(f'<li>{escape(x)}</li>' for x in passos)}</ul></div>
</section>"""


COMPACTO = """
@page { margin: 11mm 13mm 13mm; }
.legal p { font-size: 7pt; margin-bottom: 2pt; } .mini { font-size: 7pt; }
.compacta th, .compacta td { font-size: 6.6pt; padding: 1pt 3pt; }
h2 { margin: 6pt 0 3pt; } li { margin-bottom: .5pt; }
"""
MAX_PAGINAS = 4


# O navegador (Edge/Chrome) não desenha as margens de página do CSS (@bottom-left/right).
# Nesse motor o rodapé entra no fim de cada página; com no máximo 4 páginas e uma seção por
# página, "Página n de 4" é exato (o limite é conferido no PDF gerado).
RODAPE_NAVEGADOR = """
@page { @bottom-left { content: none; } @bottom-right { content: none; } }
.rodape { display: flex; justify-content: space-between; gap: 12pt; margin-top: 8pt; padding-top: 4pt;
          border-top: .5pt solid #d0d5dd; font-size: 7pt; color: #667085; }
"""


def html_relatorio(r: dict, compacto: bool = False, max_linhas: int | None = None, motor: str = "weasyprint") -> str:
    gerado = datetime.now(timezone.utc).astimezone().strftime("%d/%m/%Y %H:%M")
    paginas = [_pagina1(r, gerado), _pagina_mapa(r, "mdc"), _pagina_mapa(r, "iptu"), _pagina4(r, max_linhas)]
    if motor == "navegador":
        aviso = escape(r.get("aviso_escopo") or "")
        paginas = [p.replace("</section>", f'<div class="rodape"><span>{aviso}</span><span>Página {i} de {len(paginas)}</span></div></section>')
                   for i, p in enumerate(paginas, start=1)]
    corpo = "".join(paginas)
    css = CSS + (COMPACTO if compacto else "") + (RODAPE_NAVEGADOR if motor == "navegador" else "")
    return f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><style>{css}</style></head><body>{corpo}</body></html>"


def _weasyprint_disponivel() -> bool:
    try:
        import weasyprint  # noqa: F401  (no Windows falha ao carregar as DLLs do GTK: OSError)
        return True
    except (ImportError, OSError):
        return False


def motor_pdf() -> str:
    """'weasyprint' (servidor Linux) ou 'navegador' (Edge/Chrome em modo invisível, padrão no Windows).
    Pode ser forçado pela variável CALCGABARITO_PDF."""
    import os
    escolhido = os.environ.get("CALCGABARITO_PDF", "").lower()
    if escolhido in ("weasyprint", "navegador"):
        return escolhido
    return "weasyprint" if _weasyprint_disponivel() else "navegador"


def localizar_navegador() -> str | None:
    import os
    import shutil
    if os.environ.get("CALCGABARITO_NAVEGADOR"):
        return os.environ["CALCGABARITO_NAVEGADOR"]
    candidatos = []
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
        if base:
            candidatos += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                           os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    candidatos += [shutil.which(n) for n in ("msedge", "chromium", "chromium-browser", "google-chrome", "chrome")]
    candidatos.append("/opt/pw-browsers/chromium")
    return next((c for c in candidatos if c and os.path.exists(c)), None)


def _pdf_navegador(html: str) -> bytes:
    import os
    import subprocess
    import tempfile
    exe = localizar_navegador()
    if not exe:
        raise RuntimeError("Nenhum navegador encontrado para gerar o PDF (Microsoft Edge ou Google Chrome).")
    with tempfile.TemporaryDirectory() as tmp:
        entrada, saida = Path(tmp) / "relatorio.html", Path(tmp) / "relatorio.pdf"
        entrada.write_text(html, encoding="utf-8")
        cmd = [exe, "--headless=new", "--disable-gpu", "--no-first-run", "--no-pdf-header-footer",
               "--print-to-pdf-no-header", f"--user-data-dir={Path(tmp) / 'perfil'}",
               f"--print-to-pdf={saida}", entrada.as_uri()]
        if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(1, "--no-sandbox")
        subprocess.run(cmd, capture_output=True, timeout=90)
        if not saida.exists() or saida.stat().st_size == 0:
            raise RuntimeError("O navegador não conseguiu gerar o PDF.")
        return saida.read_bytes()


def gerar_pdf(r: dict) -> bytes:
    """Gera o PDF garantindo no máximo 4 páginas: primeiro aperta o espaçamento, depois encurta
    a tabela de lotes da página 4 (a lista completa sempre está na planilha)."""
    import io
    tentativas = [(False, None), (True, None)] + [(True, k) for k in (16, 12, 8, 4)]
    if motor_pdf() == "weasyprint":
        from weasyprint import HTML
        for compacto, max_linhas in tentativas:
            doc = HTML(string=html_relatorio(r, compacto, max_linhas)).render()
            if len(doc.pages) <= MAX_PAGINAS:
                return doc.write_pdf()
        return doc.write_pdf()
    from pypdf import PdfReader
    for compacto, max_linhas in tentativas:
        pdf = _pdf_navegador(html_relatorio(r, compacto, max_linhas, motor="navegador"))
        if len(PdfReader(io.BytesIO(pdf)).pages) <= MAX_PAGINAS:
            return pdf
    return pdf
