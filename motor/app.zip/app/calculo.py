"""Teste do art. 60, II da LPUOS e critério interno, nas bases IPTU e MDC.

Função pura: recebe lotes já montados e parâmetros, devolve um dicionário com
cada número, sua fórmula e sua fonte. Não faz I/O, então recalcular ao trocar o
gabarito ou editar uma altura é instantâneo.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .modelo import Lote

LIMITE_LEI = 50.0  # art. 60, II: "mais de 50%"

CRITERIOS_EDIFICADO = {
    "predio": "Prédio: lote em condomínio (CD) com edificação, ou edificação com altura ≥ altura mínima (10 m)",
    "condominio": "Só lote em condomínio (sigla CD no GeoSampa) com edificação (critério até 19/10/2026)",
    "altura_minima": "Lote com edificação de altura (a mesma usada no teste) ≥ altura mínima informada",
    "qualquer_edificacao": "Lote com qualquer edificação cadastrada no MDC",
}


@dataclass
class AlturaLote:
    """Altura legal da edificação mais alta do lote (art. 1º, III da Lei 18.081/2024).

    `central` é o valor de referência; `minima`/`maxima` é a faixa admissível
    (art. 61 – posição do térreo). `fonte` ∈ {"alvara", "lidar", "3d_tiles", "mdc"}.
    """
    central: float | None
    minima: float | None
    maxima: float | None
    fonte: str
    altura_topo: float | None = None   # com barrilete (modelo 3D)
    altura_mdc: float | None = None
    avisos: list[str] = field(default_factory=list)
    referencia: str | None = None      # base informada pelo usuário na entrada manual (ex.: "Alvará 2019/123")


@dataclass
class Parametros:
    gabarito_m: float
    tolerancia_m: float = 3.0
    criterio_edificado: str = "predio"
    altura_minima_edificado_m: float = 10.0
    ilustrativo: bool = False  # zona sem gabarito (ZEU/ZEUP/ZEM)


def altura_mdc(lote: Lote) -> AlturaLote:
    h = lote.altura_mdc_max
    av = ["Altura MDC (2007, aerofotogrametria): mede até o topo, com barrilete; tende a superestimar a altura legal."]
    return AlturaLote(central=h, minima=h, maxima=h, fonte="mdc", altura_mdc=h, avisos=av if h else [])


def altura_de_alvara(lote: Lote, z_terreo: float | None = None, z_laje: float | None = None,
                     altura_m: float | None = None, referencia: str | None = None) -> AlturaLote:
    if altura_m is None and z_terreo is not None and z_laje is not None:
        altura_m = z_laje - z_terreo
    ref = (referencia or "").strip()[:60] or None
    return AlturaLote(central=altura_m, minima=altura_m, maxima=altura_m, fonte="alvara",
                      altura_mdc=lote.altura_mdc_max, referencia=ref,
                      avisos=[f"Informado manualmente ({ref or 'projeto aprovado / Alvará'}); substitui a medida automática."])


def situacao(h: AlturaLote, p: Parametros) -> dict:
    """'sim' | 'nao' | 'a_confirmar' | 'sem_edificacao' | 'sem_medicao'.

    Sim = altura legal > gabarito (estritamente). A faixa admissível é alargada pela
    precisão de medição (±tolerância, exceto Alvará); se cruzar o gabarito, 'a confirmar'.
    """
    if h.central is None:
        return {"situacao": "sem_medicao", "tendencia": None}
    tol = 0.0 if h.fonte == "alvara" else p.tolerancia_m
    lo, hi = h.minima - tol, h.maxima + tol
    g = p.gabarito_m
    if lo > g:
        return {"situacao": "sim", "tendencia": "sim"}
    if hi <= g:
        return {"situacao": "nao", "tendencia": "nao"}
    return {"situacao": "a_confirmar", "tendencia": "sim" if h.central > g else "nao"}


def lote_edificado(lote: Lote, p: Parametros, altura: AlturaLote | None = None) -> bool:
    if not lote.edificacoes:
        return False
    # Mesma altura usada no teste (Alvará > LiDAR > MDC); a do MDC 2007 não vê prédios novos.
    h = altura.central if altura is not None and altura.central is not None else lote.altura_mdc_max
    alto = h is not None and h >= p.altura_minima_edificado_m
    if p.criterio_edificado == "predio":  # torre de um só dono (ex.: 036-052 F0339) não é CD
        return lote.tipo == "condominio" or alto
    if p.criterio_edificado == "condominio":
        return lote.tipo == "condominio"
    if p.criterio_edificado == "altura_minima":
        return alto
    return True


def _pct(a: float, b: float | None) -> float | None:
    return a / b * 100 if b else None


def _veredito(pct_sim: float | None, pct_max: float | None) -> str:
    if pct_sim is None:
        return "SEM DADOS"
    if pct_sim > LIMITE_LEI:
        return "SIM"
    if pct_max is not None and pct_max > LIMITE_LEI:
        return "A CONFIRMAR"
    return "NÃO"


def calcular(lotes: list[Lote], alturas: dict[str, AlturaLote], p: Parametros,
             area_quadra_mdc_oficial: float | None) -> dict:
    linhas = []
    for l in lotes:
        h = alturas.get(l.id) or altura_mdc(l)
        sit = {"situacao": "sem_edificacao", "tendencia": None} if not l.edificacoes else situacao(h, p)
        linhas.append({"lote": l, "altura": h, **sit, "edificado": lote_edificado(l, p, h)})

    bases = {}
    for base in ("iptu", "mdc"):
        def area(l: Lote) -> float | None:
            return l.area_iptu if base == "iptu" else l.area_mdc

        if base == "iptu":
            considerados = [r for r in linhas if r["lote"].tem_sql and r["lote"].area_iptu]
            a_quadra = sum(r["lote"].area_iptu for r in considerados)
            fonte_quadra = "Soma de qt_area_terreno (IPTU) dos lotes com SQL"
        else:
            considerados = linhas
            soma_poligonos = sum(r["lote"].area_mdc for r in linhas)
            a_quadra = area_quadra_mdc_oficial or soma_poligonos
            fonte_quadra = ("qt_area_quadra_fiscal (MDC)" if area_quadra_mdc_oficial
                            else "Soma das áreas dos polígonos de lote (qt_area_quadra_fiscal indisponível)")

        a_sim = sum(area(r["lote"]) or 0 for r in considerados if r["situacao"] == "sim")
        a_conf = sum(area(r["lote"]) or 0 for r in considerados if r["situacao"] == "a_confirmar")
        a_conf_sim = sum(area(r["lote"]) or 0 for r in considerados
                         if r["situacao"] == "a_confirmar" and r["tendencia"] == "sim")
        a_edif = sum(area(r["lote"]) or 0 for r in considerados if r["edificado"])
        n_lotes = sum(1 for r in considerados if r["lote"].tem_sql)

        pct_lei = _pct(a_sim, a_quadra)
        pct_lei_max = _pct(a_sim + a_conf, a_quadra)
        pct_lei_tend = _pct(a_sim + a_conf_sim, a_quadra)
        pct_edif = _pct(a_edif, a_quadra)
        pct_quebra = _pct(a_sim, a_edif)
        pct_quebra_max = _pct(a_sim + a_conf, a_edif)

        def interno(pq):
            if pct_edif is None or pq is None:
                return "SEM DADOS"
            return "SIM" if pct_edif >= 50 and pq >= 50 else "NÃO"

        bases[base] = {
            "area_quadra": a_quadra, "fonte_area_quadra": fonte_quadra, "n_lotes_com_sql": n_lotes,
            "area_acima": a_sim, "area_a_confirmar": a_conf, "area_edificada": a_edif,
            "pct_lei": pct_lei, "pct_lei_se_a_confirmar_sim": pct_lei_max,
            "pct_lei_pela_tendencia": pct_lei_tend,
            "veredito_lei": _veredito(pct_lei, pct_lei_max),
            "sensibilidade": {
                "a_confirmar_como_nao": _veredito(pct_lei, pct_lei),
                "a_confirmar_como_sim": _veredito(pct_lei_max, pct_lei_max),
                "muda": _veredito(pct_lei, pct_lei) != _veredito(pct_lei_max, pct_lei_max),
            },
            "pct_edificada": pct_edif, "pct_quebra": pct_quebra,
            "veredito_interno": interno(pct_quebra),
            "veredito_interno_se_a_confirmar_sim": interno(pct_quebra_max),
            "formulas": {
                "pct_lei": "Σ área dos lotes acima do gabarito ÷ área da quadra × 100 (art. 60, II e §1º)",
                "pct_edificada": "Σ área dos lotes edificados ÷ área da quadra × 100",
                "pct_quebra": "Σ área dos lotes acima do gabarito ÷ Σ área dos lotes edificados × 100",
            },
        }
        if area_quadra_mdc_oficial and base == "mdc":
            bases[base]["soma_poligonos_lotes"] = soma_poligonos

    vi, vm = bases["iptu"]["veredito_lei"], bases["mdc"]["veredito_lei"]
    if vi == vm:
        geral, nota = vi, None
    elif "SEM DADOS" in (vi, vm):
        geral = vm if vi == "SEM DADOS" else vi
        nota = "Uma das bases não pôde ser calculada; veredito pela base disponível."
    else:
        geral, nota = "A CONFIRMAR", (f"As bases divergem: pela área IPTU o resultado é {vi}; "
                                      f"pela área MDC, {vm}. Confirmar a área dos lotes decisivos.")

    return {"parametros": p.__dict__, "linhas": linhas, "bases": bases,
            "veredito": geral, "nota_veredito": nota}
