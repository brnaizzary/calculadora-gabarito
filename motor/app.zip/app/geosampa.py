"""Cliente do WFS público do GeoSampa, com cache em SQLite por consulta.

Toda resposta guarda a URL exata e a data/hora da consulta, para que cada número
exibido no app possa citar fonte e data. Falhas não levantam exceção para o
chamador: viram um registro em `FonteResultado.erro`, que a tela e o relatório
mostram.
"""
from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

import requests

from .config import camadas, pasta_cache

CACHE_DB = pasta_cache() / "geosampa.sqlite"


@dataclass
class FonteResultado:
    nome: str                      # rótulo legível, ex.: "Lotes (lote_cidadao)"
    url: str | None
    consultado_em: str | None      # ISO 8601, UTC
    do_cache: bool = False
    features: list[dict] = field(default_factory=list)
    erro: str | None = None

    @property
    def ok(self) -> bool:
        return self.erro is None

    def resumo(self) -> dict:
        return {
            "nome": self.nome,
            "url": self.url,
            "consultado_em": self.consultado_em,
            "do_cache": self.do_cache,
            "n_feicoes": len(self.features),
            "erro": self.erro,
        }


def _db() -> sqlite3.Connection:
    CACHE_DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(CACHE_DB)
    con.execute(
        "CREATE TABLE IF NOT EXISTS wfs (url TEXT PRIMARY KEY, consultado_em TEXT, corpo TEXT)"
    )
    return con


def montar_url(type_name: str, cql_filter: str | None = None, extra: dict | None = None) -> str:
    cfg = camadas()
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "outputFormat": "application/json",
        "typeNames": type_name,
        "srsName": cfg["srs"],
    }
    if cql_filter:
        params["CQL_FILTER"] = cql_filter
    if extra:
        params.update(extra)
    return cfg["wfs_url"] + "?" + urlencode(params)


def get_feature(nome: str, type_name: str | None, cql_filter: str | None,
                usar_cache: bool = True, sessao: requests.Session | None = None) -> FonteResultado:
    if not type_name:
        return FonteResultado(nome, None, None,
                              erro="Camada não configurada em config/camadas.json.")
    url = montar_url(type_name, cql_filter)

    if usar_cache:
        with _db() as con:
            row = con.execute("SELECT consultado_em, corpo FROM wfs WHERE url=?", (url,)).fetchone()
        if row:
            return FonteResultado(nome, url, row[0], True, json.loads(row[1]).get("features", []))

    cfg = camadas()
    s = sessao or requests.Session()
    ultimo_erro = None
    for tentativa in range(cfg.get("tentativas", 3)):
        try:
            r = s.get(url, timeout=cfg.get("timeout_s", 60))
            r.raise_for_status()
            corpo = r.json()  # GeoServer devolve XML de exceção com status 200 às vezes
            if "features" not in corpo:
                raise ValueError(f"Resposta sem 'features': {str(corpo)[:200]}")
            agora = datetime.now(timezone.utc).isoformat(timespec="seconds")
            with _db() as con:
                con.execute("INSERT OR REPLACE INTO wfs VALUES (?,?,?)", (url, agora, json.dumps(corpo)))
            return FonteResultado(nome, url, agora, False, corpo["features"])
        except (requests.RequestException, ValueError) as e:
            ultimo_erro = f"{type(e).__name__}: {e}"
            time.sleep(2 ** tentativa)
    return FonteResultado(nome, url, datetime.now(timezone.utc).isoformat(timespec="seconds"),
                          erro=f"GeoSampa indisponível ou consulta rejeitada ({ultimo_erro}).")


def listar_camadas(busca: str = "", sessao: requests.Session | None = None) -> list[str]:
    """Lê o GetCapabilities e devolve os typeNames que contêm `busca` (para descobrir
    a camada de zoneamento vigente sem chutar o nome)."""
    import re
    cfg = camadas()
    url = cfg["wfs_url"] + "?" + urlencode({"service": "WFS", "version": "2.0.0", "request": "GetCapabilities"})
    r = (sessao or requests).get(url, timeout=cfg.get("timeout_s", 60))
    r.raise_for_status()
    nomes = re.findall(r"<(?:wfs:)?Name>([^<]+)</(?:wfs:)?Name>", r.text)
    return sorted({n for n in nomes if busca.lower() in n.lower()})


def limpar_cache(prefixo_url: str | None = None) -> int:
    with _db() as con:
        if prefixo_url:
            cur = con.execute("DELETE FROM wfs WHERE url LIKE ?", (prefixo_url + "%",))
        else:
            cur = con.execute("DELETE FROM wfs")
        return cur.rowcount
