"""Leitura das configurações editáveis (config/*.json). Relidas a cada chamada para
que uma edição da tabela do Quadro 3 valha sem reiniciar o servidor."""
from __future__ import annotations

import json
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


def pasta_cache() -> Path:
    """Onde ficam o cache do GeoSampa e o LiDAR (centenas de MB). No Windows, em
    %LOCALAPPDATA%\\CalcGabarito\\cache, fora da pasta do app (que pode estar no OneDrive).
    Pode ser trocada pela variável de ambiente CALCGABARITO_CACHE."""
    import os
    if os.environ.get("CALCGABARITO_CACHE"):
        return Path(os.environ["CALCGABARITO_CACHE"])
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "CalcGabarito" / "cache"
    return Path(__file__).resolve().parent.parent / "cache"


def _ler(nome: str) -> dict:
    return json.loads((CONFIG_DIR / nome).read_text(encoding="utf-8"))


def camadas() -> dict:
    return _ler("camadas.json")


def gabaritos() -> dict:
    return _ler("gabaritos.json")


def salvar_gabaritos(dados: dict) -> None:
    (CONFIG_DIR / "gabaritos.json").write_text(
        json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")


def validar_gabaritos(dados: dict) -> dict:
    """Confere a tabela do Quadro 3 editada na tela e devolve a tabela completa pronta para salvar.
    Levanta ValueError com a mensagem para o usuário."""
    import re
    zonas = dados.get("zonas")
    if not isinstance(zonas, dict) or not zonas:
        raise ValueError("A tabela precisa ter ao menos uma zona.")
    limpas = {}
    for sigla, z in zonas.items():
        s = str(sigla).strip()
        if not re.fullmatch(r"[A-Za-z0-9-]{1,12}", s) or not isinstance(z, dict):
            raise ValueError(f"Zona inválida: {sigla!r}.")
        g = z.get("gabarito_m")
        if g is not None and (not isinstance(g, (int, float)) or not 0 < g <= 300):
            raise ValueError(f"Gabarito de {s} deve ser um número entre 0 e 300 m, ou vazio para 'sem limite'.")
        if s.upper() in {k.upper() for k in limpas}:
            raise ValueError(f"Zona repetida: {s}.")
        limpas[s] = {"gabarito_m": g, "confirmado": bool(z.get("confirmado")), "obs": str(z.get("obs") or "")[:300]}
    atual = gabaritos()
    atual["zonas"] = limpas
    atual["_editado_em"] = str(dados.get("_editado_em") or "")[:10]
    return atual


def gabarito_da_zona(sigla: str | None) -> dict:
    """Devolve {'sigla', 'gabarito_m', 'sem_limite', 'na_tabela', 'confirmado', 'obs'}.

    Correspondência exata da sigla: variantes como ZMa ou ZCa têm parâmetros próprios no
    Quadro 3 e precisam de linha própria na tabela; nunca herdam o valor de ZM ou ZC.
    """
    tab = gabaritos()["zonas"]
    if not sigla:
        return {"sigla": None, "gabarito_m": None, "sem_limite": False, "na_tabela": False,
                "confirmado": False, "obs": "Zona não identificada."}
    chaves = {k.upper(): k for k in tab}  # busca sem diferenciar maiúsculas; mantém a grafia oficial (ZEUa)
    s = chaves.get(sigla.strip().upper())
    if s is None:
        return {"sigla": sigla.strip(), "gabarito_m": None, "sem_limite": False, "na_tabela": False,
                "confirmado": False, "obs": "Zona sem gabarito cadastrado na tabela do Quadro 3."}
    z = tab[s]
    return {"sigla": s, "zona_base": s, "gabarito_m": z["gabarito_m"],
            "sem_limite": z["gabarito_m"] is None, "na_tabela": True,
            "confirmado": z.get("confirmado", False), "obs": z.get("obs", "")}

