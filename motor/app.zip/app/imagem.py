"""Entrada por imagem: identifica a quadra fiscal num print (GeoSampa, Google Maps, ficha técnica).

1. OCR (Tesseract, português) da imagem em vários ângulos, porque nomes de rua em mapas vêm inclinados.
2. Se houver SQL ou setor/quadra legíveis, usa direto.
3. Senão, procura no próprio GeoSampa (camada lote_cidadao) os lotes com a rua e o número lidos;
   sem número, cruza as quadras que têm lotes em todas as ruas lidas.
4. Devolve candidatas para o usuário confirmar. Nada é calculado sem confirmação.
"""
from __future__ import annotations

import difflib
import re
import unicodedata
from io import BytesIO

from . import geosampa
from .config import camadas

ANGULOS = list(range(-80, 91, 10))
TIPOS = {"RUA": "R", "R": "R", "AVENIDA": "AV", "AV": "AV", "ALAMEDA": "AL", "AL": "AL", "PRACA": "PC",
         "PCA": "PC", "PC": "PC", "TRAVESSA": "TV", "TV": "TV", "TRAV": "TV", "ESTRADA": "EST", "EST": "EST",
         "LARGO": "LGO", "LGO": "LGO", "VIADUTO": "VD", "VD": "VD"}
_RE_SQL = re.compile(r"(?<!\d)(\d{3})[.\s](\d{3})[.\s](\d{4})-?(\d)?(?!\d)")
_RE_SQ = re.compile(r"SETOR\W{0,3}(\d{1,3})\W{1,6}QUADRA\W{0,3}(\d{1,3})", re.I)
_RE_RUA = re.compile(r"\b(RUA|R|AVENIDA|AV|ALAMEDA|AL|PRACA|PCA|PC|TRAVESSA|TRAV|TV|ESTRADA|EST|LARGO|LGO|VIADUTO|VD)"
                     r"\.?\s+([A-Z][A-Z' ]{2,40})(?:\s*[,\-–]?\s*(?:N[OºO°]?\.?\s*)?(\d{1,5}))?")


def sem_acento(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).upper()


class TesseractAusente(RuntimeError):
    pass


def _configurar_tesseract():
    """Acha o tesseract.exe no Windows (o instalador não o coloca no PATH) e confere o idioma português."""
    import os
    import shutil
    import pytesseract
    exe = os.environ.get("CALCGABARITO_TESSERACT") or shutil.which("tesseract")
    if not exe:
        for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA")):
            c = os.path.join(base, "Tesseract-OCR", "tesseract.exe") if base else None
            if c and os.path.exists(c):
                exe = c
                break
    if not exe:
        raise TesseractAusente("O leitor de imagens (Tesseract) não está instalado neste computador. "
                               "Veja o guia de instalação; enquanto isso, informe setor e quadra nos campos.")
    pytesseract.pytesseract.tesseract_cmd = exe
    if "por" not in pytesseract.get_languages(config=""):
        raise TesseractAusente("O Tesseract está instalado sem o idioma português. Reinstale marcando "
                               "\"Portuguese\" em \"Additional language data\".")
    return pytesseract


def ocr(conteudo: bytes) -> str:
    pytesseract = _configurar_tesseract()
    from PIL import Image, ImageOps
    im = Image.open(BytesIO(conteudo))
    im = ImageOps.exif_transpose(im).convert("L")
    if max(im.size) < 1600:  # amplia prints pequenos: o Tesseract lê melhor letras com ~30 px
        f = 1600 / max(im.size)
        im = im.resize((int(im.width * f), int(im.height * f)))
    im = ImageOps.autocontrast(im)
    textos = [pytesseract.image_to_string(im, lang="por", config="--psm 6")]
    for ang in ANGULOS:
        textos.append(pytesseract.image_to_string(im.rotate(ang, expand=True, fillcolor=255), lang="por",
                                                  config="--psm 11"))
    return "\n".join(textos)


def extrair(texto: str) -> dict:
    t = sem_acento(texto)
    sqls = sorted({f"{a}.{b}.{c}" + (f"-{d}" if d else "") for a, b, c, d in _RE_SQL.findall(t)})
    sq = sorted({(s.zfill(3), q.zfill(3)) for s, q in _RE_SQ.findall(t)})
    enderecos, ruas = set(), set()
    for linha in t.split("\n"):
        for tipo, nome, num in _RE_RUA.findall(linha):
            palavras = [w for w in nome.split() if len(w) > 1]
            if num and palavras and palavras[-1] in ("NO", "NUM", "NUMERO"):  # "nº 2000"
                palavras = palavras[:-1]
            nome = " ".join(palavras)
            if len(nome.replace(" ", "")) < 4:
                continue
            ruas.add((TIPOS[tipo], nome))
            if num and int(num) > 0:
                enderecos.add((TIPOS[tipo], nome, int(num)))
    # junta leituras parciais da mesma rua ("PIAU" e "PIAUI"): fica a mais longa
    ruas = {r for r in ruas if not any(o != r and o[0] == r[0] and o[1].startswith(r[1]) for o in ruas)}
    return {"sqls": sqls, "setor_quadra": [list(x) for x in sq],
            "enderecos": [list(e) for e in sorted(enderecos)], "ruas": [list(r) for r in sorted(ruas)]}


# ------------------------------------------------------------------ busca no GeoSampa

def _lotes_da_rua(nome: str, numero: int | None = None) -> list[dict]:
    f = camadas()["lote"]
    seguro = re.sub(r"[^A-Z0-9 ]", "", nome)[:40].strip()
    if len(seguro) < 4:
        return []
    chave = max(seguro.split(), key=len)  # palavra mais longa: tolera nomes truncados pelo OCR
    cql = f"{f['campo_logradouro']} ILIKE '%{chave}%'"
    if numero is not None:
        cql += f" AND {f['campo_numero']}={int(numero)}"
    r = geosampa.get_feature(f"Busca de logradouro ({chave})", f["typeName"], cql)
    return r.features if r.ok else []


def _mesmo_nome(lido: str, oficial: str) -> bool:
    """Compara o nome lido no print com o do GeoSampa (sem o tipo do logradouro)."""
    partes = sem_acento(oficial).split(maxsplit=1)
    nome_of = partes[1] if len(partes) > 1 and partes[0] in TIPOS.values() else sem_acento(oficial)
    if lido == nome_of:
        return True
    if len(lido) >= 6 and nome_of.startswith(lido):  # "PERNAMBUC" lido de "PERNAMBUCO"
        return True
    return difflib.SequenceMatcher(None, lido, nome_of).ratio() >= 0.88


def identificar(extraido: dict) -> list[dict]:
    f = camadas()["lote"]
    cand: dict[tuple, dict] = {}

    def add(s, q, motivo, peso):
        c = cand.setdefault((s, q), {"setor": s, "quadra": q, "motivos": [], "pontos": 0})
        if motivo not in c["motivos"]:
            c["motivos"].append(motivo)
            c["pontos"] += peso

    for sql in extraido["sqls"]:
        s, q = sql.split(".")[:2]
        add(s, q, f"SQL {sql} lido na imagem", 100)
    for s, q in extraido["setor_quadra"]:
        add(s, q, f"Setor {s} e quadra {q} lidos na imagem", 90)
    if cand:
        return _ordenar(cand)

    for tipo, nome, num in extraido["enderecos"]:
        for feat in _lotes_da_rua(nome, num):
            p = feat["properties"]
            if _mesmo_nome(nome, p.get(f["campo_logradouro"]) or ""):
                add(p[f["campo_setor"]], p[f["campo_quadra"]],
                    f"{p.get(f['campo_logradouro'])}, {num} fica nesta quadra", 50)

    quadras_por_rua = []
    for tipo, nome in extraido["ruas"][:6]:
        qs = {(ft["properties"][f["campo_setor"]], ft["properties"][f["campo_quadra"]]): ft["properties"][f["campo_logradouro"]]
              for ft in _lotes_da_rua(nome) if _mesmo_nome(nome, ft["properties"].get(f["campo_logradouro"]) or "")}
        if qs:
            quadras_por_rua.append(qs)
    if len(quadras_por_rua) >= 2:
        comuns = set.intersection(*(set(q) for q in quadras_por_rua))
        if not comuns:  # OCR pode ter lido uma rua vizinha: aceita quadras em pelo menos 2 ruas
            from collections import Counter
            cont = Counter(k for q in quadras_por_rua for k in q)
            comuns = {k for k, v in cont.items() if v >= 2}
        for k in comuns:
            nomes = sorted({q[k] for q in quadras_por_rua if k in q})
            add(k[0], k[1], f"Tem lotes em {', '.join(nomes)}", 10 * len(nomes))
    return _ordenar(cand)


def _ordenar(cand: dict) -> list[dict]:
    return sorted(cand.values(), key=lambda c: (-c["pontos"], c["setor"], c["quadra"]))[:8]


def previa(setor: str, quadra: str) -> dict:
    """Contorno da quadra candidata (SVG pequeno) para o usuário conferir antes de confirmar."""
    from .modelo import geometria_utm
    from shapely.ops import unary_union
    fq = camadas()["quadra"]
    r = geosampa.get_feature("Quadra fiscal (quadra_fiscal)", fq["typeName"],
                             f"{fq['campo_setor']}='{setor}' AND {fq['campo_quadra']}='{quadra}'")
    if not r.ok or not r.features:
        return {"existe": False, "svg": None, "area": None}
    g = unary_union([geometria_utm(x["geometry"]) for x in r.features if x.get("geometry")])
    x0, y0, x1, y1 = g.buffer(8).bounds
    esc = 220 / max(x1 - x0, y1 - y0)
    w, h = (x1 - x0) * esc, (y1 - y0) * esc
    polys = [g] if g.geom_type == "Polygon" else list(g.geoms)
    d = " ".join("M" + " L".join(f"{(x - x0) * esc:.1f},{(y1 - y) * esc:.1f}" for x, y in p.exterior.coords) + "Z"
                 for p in polys)
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w:.0f} {h:.0f}" width="100%">'
           f'<path d="{d}" fill="#f4c7c3" stroke="#b42318" stroke-width="1.5"/></svg>')
    return {"existe": True, "svg": svg, "area": round(g.area, 2)}


def analisar_imagem(conteudo: bytes) -> dict:
    texto = ocr(conteudo)
    ext = extrair(texto)
    cands = identificar(ext)
    for c in cands[:5]:
        c.update(previa(c["setor"], c["quadra"]))
    cands = [c for c in cands[:5] if c.get("existe")]
    if not cands:
        msg = ("Não foi possível identificar a quadra pela imagem. Informe setor e quadra nos campos acima"
               + (" (ruas lidas: " + ", ".join(f"{t} {n}" for t, n in ext["ruas"]) + ")." if ext["ruas"] else "."))
    elif len(cands) == 1:
        msg = "Quadra identificada. Confira o contorno e confirme antes de calcular."
    else:
        msg = "Mais de uma quadra possível. Escolha a correta (a primeira é a mais provável)."
    linhas = [l.strip() for l in texto.split("\n") if len(l.strip()) > 2]
    return {"candidatos": cands, "extraido": ext, "mensagem": msg,
            "texto_lido": "\n".join(dict.fromkeys(linhas))[:3000]}
