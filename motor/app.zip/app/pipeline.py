"""Orquestra coleta, montagem, validações, cálculo e textos de uma quadra."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from shapely.geometry.base import BaseGeometry

from . import geosampa
from .calculo import (CRITERIOS_EDIFICADO, AlturaLote, Parametros, altura_de_alvara,
                      altura_mdc, calcular)
from .config import camadas, gabarito_da_zona, gabaritos
from .modelo import (Edificacao, Lote, atribuir_edificacoes, geojson, montar_edificacoes,
                     montar_lotes, _num)

AVISO_ESCOPO = ("Indicativo técnico; não substitui consulta à SMUL nem análise do "
                "COMAER/DECEA.")

TEXTO_LEGAL = {
    "art60_caput": "Art. 60. O gabarito de altura máxima (GAB) da edificação será o definido no Quadro 3 desta lei, exceto:",
    "art60_I": "I - nos imóveis inseridos no perímetro da Operação Urbana Centro, que deverão respeitar as disposições da "
               "Lei n° 12.349, de 6 de junho de 1997, e as alterações que vierem a sucedê-la;",
    "art60_II": "II - nas quadras nas quais em mais de 50% (cinquenta por cento) da área dos lotes as edificações existentes "
                "já tenham ultrapassado os limites previstos no referido quadro.",
    "art60_p1": "§ 1º Serão consideradas, para fins de aplicação da exceção prevista no inciso II deste artigo, as áreas dos "
                "lotes com edificações existentes com gabarito maior que o disposto nesta lei.",
    "art60_p2": "§ 2º Nos casos dos terrenos que contenham total ou parcialmente declive ou aclive acima de 30% (trinta por cento) "
                "identificado no mapa digital oficial do município ou em levantamento topográfico atualizado e atestado por "
                "profissional habilitado, a edificação deverá obedecer ao gabarito de altura máxima de 28m (vinte e oito metros).",
    "art61": "Art. 61. Para fins do disposto nesta lei, o nível do pavimento térreo não poderá exceder a cota de 1m (um metro) "
             "acima do nível médio entre as cotas das extremidades da testada do lote, quando o desnível da testada for menor "
             "ou igual a 2m (dois metros). § 1º Quando o desnível na testada do lote for superior a 2m (dois metros), o piso do "
             "pavimento térreo poderá estar situado em qualquer cota intermediária entre os níveis mais elevado e mais baixo. "
             "§ 2º O disposto no § 1º deste artigo também será aplicado aos casos de desníveis superiores a 2m (dois metros) em "
             "relação à profundidade do lote. § 3º O nível do pavimento térreo não poderá ser inferior à menor cota dos vértices "
             "do terreno. (Redação dada pela Lei nº 18.081/2024)",
    "art1_III_18081": "Lei 18.081/2024, art. 1º, III – gabarito é a diferença entre o pavimento térreo e o nível da cobertura, "
                      "excluídos ático, casa de máquinas e caixa d'água.",
    "ceuso_160": "Resolução CEUSO 160/2025 – testada irregular: nível médio = (maior + menor nível dos vértices) ÷ 2.",
    "_obs": "Arts. 60 e 61: texto literal da Lei 16.402/2016 consolidada (legislacao.prefeitura.sp.gov.br, consultado em "
            "19/10/2026). Art. 1º, III da Lei 18.081/2024 e Res. CEUSO 160/2025: resumos do briefing.",
}


@dataclass
class DadosQuadra:
    setor: str
    quadra: str
    geom_quadra: BaseGeometry | None
    area_quadra_mdc: float | None
    lotes: list[Lote]
    atribuicao: dict
    zona: dict
    distrito: str | None
    fontes: list[geosampa.FonteResultado]
    avisos_coleta: list[str] = field(default_factory=list)
    duracao_s: float = 0.0
    alturas_lidar: dict = field(default_factory=dict)   # lote_id -> AlturaLote
    medicoes_lidar: dict = field(default_factory=dict)  # lote_id -> testada, cobertura, declividade
    zonas_lote: dict = field(default_factory=dict)      # lote_id -> sigla da zona (maior interseção)
    zonas_vizinhas: list = field(default_factory=list)  # siglas das zonas no entorno (consulta por BBOX)


_memoria: dict[tuple[str, str], DadosQuadra] = {}


def coletar(setor: str, quadra: str, usar_cache: bool = True,
            progresso=lambda etapa: None) -> DadosQuadra:
    if usar_cache and (setor, quadra) in _memoria:
        return _memoria[(setor, quadra)]
    t0 = time.time()
    cfg = camadas()
    fq, fl, fe = cfg["quadra"], cfg["lote"], cfg["edificacao"]
    avisos = []

    progresso("quadra")
    filtro = f"{fq['campo_setor']}='{setor}' AND {fq['campo_quadra']}='{quadra}'"
    r_quadra = geosampa.get_feature("Quadra fiscal (quadra_fiscal)", fq["typeName"], filtro, usar_cache)
    geom_q, area_q = None, None
    if r_quadra.ok and r_quadra.features:
        from shapely.ops import unary_union
        from .modelo import geometria_utm
        geom_q = unary_union([geometria_utm(f["geometry"]) for f in r_quadra.features if f.get("geometry")])
        area_q = _num(r_quadra.features[0]["properties"].get(fq["campo_area"]))
        if len(r_quadra.features) > 1:
            avisos.append(f"A quadra veio em {len(r_quadra.features)} polígonos; foram unidos.")
    elif r_quadra.ok:
        r_quadra.erro = f"Quadra {setor}-{quadra} não encontrada no GeoSampa."

    progresso("lotes")
    filtro_l = f"{fl['campo_setor']}='{setor}' AND {fl['campo_quadra']}='{quadra}'"
    r_lotes = geosampa.get_feature("Lotes (lote_cidadao)", fl["typeName"], filtro_l, usar_cache)
    lotes, av = montar_lotes(r_lotes.features, setor, quadra) if r_lotes.ok else ([], [])
    avisos += av
    if geom_q is None and lotes:
        from shapely.ops import unary_union
        geom_q = unary_union([l.geom for l in lotes])
        avisos.append("Geometria da quadra substituída pela união dos lotes.")

    progresso("edificacoes")
    fontes = [r_quadra, r_lotes]
    atrib = {"fora_da_quadra": 0, "sem_lote": [], "em_lotes_sobrepostos": [],
             "lotes_sem_edificacao": [l.id for l in lotes]}
    if geom_q is not None:
        x0, y0, x1, y1 = geom_q.buffer(1).bounds
        filtro_e = f"BBOX({fe['campo_geometria']},{x0:.2f},{y0:.2f},{x1:.2f},{y1:.2f})"
        r_edif = geosampa.get_feature("Edificações MDC (edificacao)", fe["typeName"], filtro_e, usar_cache)
        fontes.append(r_edif)
        if r_edif.ok:
            atrib = atribuir_edificacoes(lotes, montar_edificacoes(r_edif.features), geom_q)

    progresso("zoneamento")
    zona_sigla, zona_info = None, {}
    distrito = None
    if geom_q is not None:
        zona_sigla, zona_info, r_z = _sigla_predominante(cfg["zoneamento"], "campo_sigla",
                                                         "Zoneamento (Lei 18.081/2024)", geom_q, usar_cache)
        fontes.append(r_z)
        distrito, _, r_d = _sigla_predominante(cfg["distrito"], "campo_nome", "Distrito", geom_q, usar_cache)
        fontes.append(r_d)
        if cfg.get("zoneamento_comparar", {}).get("typeName"):
            z2, comp2, r_z2 = _sigla_predominante(cfg["zoneamento_comparar"], "campo_sigla",
                                                  "Zoneamento – conferência (Lei 18.177/2024)", geom_q, usar_cache)
            fontes.append(r_z2)
            if r_z2.ok and z2 and zona_sigla and z2 != zona_sigla:
                avisos.append(f"Pela Lei 18.177/2024 a quadra seria {z2}; a análise usa {zona_sigla}, da Lei 18.081/2024. "
                              "A 18.177 está sob discussão judicial e pode ser suspensa; acompanhar se ela voltar a valer.")

    zona = gabarito_da_zona(zona_sigla)
    zona["composicao"] = zona_info
    feats_z = r_z.features if geom_q is not None and r_z.ok else []
    zonas_lote = _zona_por_lote(cfg["zoneamento"], feats_z, lotes)
    campo_z = cfg["zoneamento"].get("campo_sigla") or ""
    vizinhas = sorted({str(f["properties"].get(campo_z) or "").strip() for f in feats_z} - {""})

    progresso("alturas")
    alt, med = {}, {}
    if geom_q is not None and lotes and cfg.get("lidar"):
        try:
            from . import lidar
            mds, mdt, f_lidar = lidar.nuvens(geom_q, setor, quadra, usar_cache)
            fontes += f_lidar
            if mds is not None:
                for l in lotes:
                    alt[l.id], med[l.id] = lidar.altura_lidar(l, geom_q, mds, mdt, cfg["lidar"].get("cobertura"))
                    nova = med[l.id].pop("pegada_nova", None)
                    if nova is not None:  # prédio que não existia no MDC 2007
                        l.edificacoes.append(Edificacao(f"LIDAR-{l.id}", nova, None, l.id,
                                                        ["Pegada estimada pelo LiDAR 2020 (ausente no MDC 2007)."]))
                        atrib["lotes_sem_edificacao"] = [i for i in atrib.get("lotes_sem_edificacao", []) if i != l.id]
        except Exception as e:  # LiDAR é opcional: sem ele o app segue com a altura MDC, sinalizando
            fontes.append(geosampa.FonteResultado("LiDAR 2020", None, None, erro=f"{type(e).__name__}: {e}"))

    dados = DadosQuadra(setor, quadra, geom_q, area_q, lotes, atrib, zona, distrito, fontes, avisos,
                        time.time() - t0, alt, med, zonas_lote, vizinhas)
    if all(f.ok for f in (r_quadra, r_lotes)):
        _memoria[(setor, quadra)] = dados
    return dados


def _sigla_predominante(c: dict, campo: str, nome: str, geom_q: BaseGeometry, usar_cache: bool):
    """Consulta a camada por BBOX e calcula a área de interseção local (evita URL com WKT longo)."""
    if not c.get("typeName") or not c.get("campo_geometria") or not c.get(campo):
        return None, {}, geosampa.FonteResultado(nome, None, None, erro="Camada não configurada em config/camadas.json.")
    from .modelo import geometria_utm
    x0, y0, x1, y1 = geom_q.bounds
    r = geosampa.get_feature(nome, c["typeName"],
                             f"BBOX({c['campo_geometria']},{x0:.2f},{y0:.2f},{x1:.2f},{y1:.2f})", usar_cache)
    if not r.ok:
        return None, {}, r
    areas: dict[str, float] = {}
    for f in r.features:
        if not f.get("geometry"):
            continue
        a = geometria_utm(f["geometry"]).intersection(geom_q).area
        s = str(f["properties"].get(c[campo]) or "").strip()
        if a > 1 and s:
            areas[s] = areas.get(s, 0) + a
    if not areas:
        return None, {}, r
    total = sum(areas.values())
    comp = {k: round(v / total * 100, 1) for k, v in sorted(areas.items(), key=lambda kv: -kv[1])}
    return max(areas, key=areas.get), comp, r


def referencias_zonas(dados: DadosQuadra) -> list[dict]:
    """Gabaritos (tabela do Quadro 3) das zonas presentes na quadra, para os botões da tela."""
    out = []
    for sigla in (dados.zona.get("composicao") or {dados.zona.get("sigla"): 100}):
        z = gabarito_da_zona(sigla)
        if z.get("gabarito_m") is not None:
            out.append({"zona": z["sigla"], "gabarito_m": z["gabarito_m"]})
    if not out:  # quadra sem gabarito aplicável (ex.: ZEU): compara com as zonas vizinhas
        vistos = set()
        for sigla in dados.zonas_vizinhas:
            z = gabarito_da_zona(sigla)
            if z.get("gabarito_m") is not None and z["sigla"] not in vistos:
                vistos.add(z["sigla"])
                out.append({"zona": z["sigla"], "gabarito_m": z["gabarito_m"], "vizinha": True})
    return out[:6]


def _zona_por_lote(c: dict, features: list[dict], lotes: list[Lote]) -> dict:
    """Zona de cada lote = a de maior área de interseção com o polígono do lote."""
    from .modelo import geometria_utm
    zonas = [(str(f["properties"].get(c.get("campo_sigla") or "") or "").strip(), geometria_utm(f["geometry"]))
             for f in features if f.get("geometry")]
    out = {}
    for l in lotes:
        melhor = max(((s, g.intersection(l.geom).area) for s, g in zonas if s), key=lambda x: x[1], default=None)
        if melhor and melhor[1] > 0.5:
            out[l.id] = melhor[0]
    return out


def zona_de_referencia(dados: DadosQuadra, estudo_ids: set[str]) -> tuple[dict, str]:
    """Zona cujo gabarito vale no teste: a do terreno em estudo (se informado e numa só zona);
    senão a predominante na quadra. Relida da tabela a cada análise (a tabela é editável)."""
    zonas_estudo = {dados.zonas_lote.get(i) for i in estudo_ids} - {None}
    if len(zonas_estudo) == 1:
        sigla, origem = zonas_estudo.pop(), "terreno em estudo"
    else:
        sigla, origem = dados.zona.get("sigla"), "predominante na quadra"
    z = gabarito_da_zona(sigla)
    z["composicao"] = dados.zona.get("composicao") or {}
    if len(zonas_estudo) > 1:
        origem = "predominante na quadra (o terreno em estudo abrange mais de uma zona)"
    return z, origem


# ------------------------------------------------------------------ análise

def analisar(dados: DadosQuadra, gabarito_m: float | None = None, criterio_edificado: str | None = None,
             altura_minima_edificado_m: float | None = None, alturas_manuais: dict | None = None,
             estudo: list[str] | None = None) -> dict:
    g = gabaritos()
    estudo_set = {e.strip().upper() for e in (estudo or []) if e.strip()}
    estudo_ids = {l.id for l in dados.lotes if l.id.upper() in estudo_set or (l.sql and l.sql in estudo_set)}
    zona, origem_zona = zona_de_referencia(dados, estudo_ids)
    zona["origem"] = origem_zona
    ilustrativo = zona.get("sem_limite", False) or zona.get("gabarito_m") is None
    if gabarito_m is None:
        gabarito_m = zona.get("gabarito_m") or g["gabarito_ilustrativo_padrao_m"]
    elif zona.get("gabarito_m") is not None and float(gabarito_m) != float(zona["gabarito_m"]):
        zona["gabarito_alterado"] = True
    p = Parametros(gabarito_m=float(gabarito_m), tolerancia_m=g["tolerancia_altura_m"],
                   criterio_edificado=criterio_edificado or "predio",
                   altura_minima_edificado_m=altura_minima_edificado_m or 10.0,
                   ilustrativo=ilustrativo)

    alturas: dict[str, AlturaLote] = {}
    por_id = {l.id: l for l in dados.lotes}
    for lid, v in (alturas_manuais or {}).items():
        if lid in por_id and v:
            alturas[lid] = altura_de_alvara(por_id[lid], _num(v.get("z_terreo")), _num(v.get("z_laje")),
                                            _num(v.get("altura_m")), v.get("referencia"))
    for l in dados.lotes:
        h = dados.alturas_lidar.get(l.id)
        if h is not None and h.central is None and l.edificacoes:
            fallback = altura_mdc(l)
            fallback.avisos = h.avisos + ["Sem medição LiDAR: usada a altura MDC."] + fallback.avisos
            h = fallback
        alturas.setdefault(l.id, h or altura_mdc(l))

    res = calcular(dados.lotes, alturas, p, dados.area_quadra_mdc)
    validacoes = _validacoes(dados, res, g)
    alertas = _alertas(dados, res, p, zona)
    linhas_json = [_linha_json(r, g["limite_divergencia_area_pct"]) for r in res["linhas"]]
    for lj in linhas_json:
        lj["zona"] = dados.zonas_lote.get(lj["id"])
    mapas = {}
    if dados.geom_quadra is not None:
        from .mapa import svg_quadra
        for modo in ("mdc", "iptu"):
            mapas[modo] = svg_quadra(dados.lotes, linhas_json, dados.geom_quadra, modo, estudo_ids, p.gabarito_m,
                                     limite_div_pct=g["limite_divergencia_area_pct"])
    return {
        "identificacao": {"setor": dados.setor, "quadra": dados.quadra, "distrito": dados.distrito,
                          "zona": zona, "enderecos": sorted({l.endereco for l in dados.lotes if l.endereco})},
        "veredito": res["veredito"],
        "nota_veredito": res["nota_veredito"],
        "frase": _frase(res, p),
        "parametros": res["parametros"],
        "criterios_edificado": CRITERIOS_EDIFICADO,
        "referencias": referencias_zonas(dados),
        "bases": res["bases"],
        "lotes": linhas_json,
        "estudo": sorted(estudo_ids),
        "estudo_nao_encontrado": sorted(estudo_set - {i.upper() for i in estudo_ids}
                                        - {l.sql for l in dados.lotes if l.id in estudo_ids and l.sql}),
        "mapas": mapas,
        "atribuicao": dados.atribuicao,
        "validacoes": validacoes,
        "alertas": alertas,
        "fontes": [f.resumo() for f in dados.fontes],
        "falhas": [f.resumo() for f in dados.fontes if not f.ok],
        "avisos_coleta": dados.avisos_coleta,
        "texto_legal": TEXTO_LEGAL,
        "aviso_escopo": AVISO_ESCOPO,
        "limitacoes": LIMITACOES,
        "geometria": {
            "quadra": geojson(dados.geom_quadra) if dados.geom_quadra is not None else None,
            "lotes": {l.id: geojson(l.geom) for l in dados.lotes},
            "edificacoes": [{"id": e.id, "lote": e.lote_id, "altura_mdc": e.altura_mdc, "geom": geojson(e.geom)}
                            for l in dados.lotes for e in l.edificacoes],
        },
        "duracao_coleta_s": round(dados.duracao_s, 2),
        "medicoes_lidar": {k: _medicao_json(v) for k, v in dados.medicoes_lidar.items()},
    }


LIMITACOES = [
    "Precisão das alturas medidas por modelo 3D: cerca de ±3 m. Casos a menos de 3 m do gabarito ficam como \"a confirmar\".",
    "O MDC de edificações é de 2007; prédios novos podem faltar e a altura inclui barrilete.",
    "O térreo real depende do projeto aprovado; o app estima pelo art. 61 (nível médio da testada).",
    "A cobertura é o nível mais alto do prédio visto de cima. Volumes menores assentados sobre ela (até 40% da área e "
    "até 8 m acima) são tratados como ático, casa de máquinas ou caixa d'água e excluídos; maiores ficam \"a confirmar\", "
    "pois podem ser cobertura habitável, que entra no gabarito. Esses limites são critério técnico do app: a lei "
    "(COE, art. 3º, VI) define o ático pelo uso, sem limite de área. Confirmar com o Alvará.",
    "O LiDAR é de 2020: prédios construídos ou ampliados depois disso não aparecem.",
    "Prédios antigos foram aprovados por regras anteriores; confirmar com a SMUL como a exceção é aplicada a eles.",
    "Gabarito do Quadro 3 e restrições do COMAER devem ser confirmados para cada caso.",
]


def _medicao_json(m: dict) -> dict:
    t, c = m.get("testada") or {}, m.get("cobertura") or {}
    r2 = lambda v: None if v is None else round(v, 2)
    return {"declividade_pct": r2(m.get("declividade_pct")), "nivel_medio_testada": r2(t.get("nivel_medio")),
            "desnivel_testada": r2(t.get("desnivel")), "cota_maior_testada": r2(t.get("maior")),
            "cota_menor_testada": r2(t.get("menor")), "z_laje": r2(c.get("z_laje")), "z_topo": r2(c.get("z_topo")),
            "z_laje_max": r2(c.get("z_laje_max")), "area_cobertura_m2": r2(c.get("area_cobertura_m2")),
            "n_celulas_cobertura": c.get("n_pontos"), "niveis": c.get("niveis") or []}


def _linha_json(r: dict, lim_div: float) -> dict:
    l, h = r["lote"], r["altura"]
    d = l.diferenca_pct
    return {
        "id": l.id, "tipo": l.tipo, "sql": l.sql, "endereco": l.endereco, "condominio": l.cd_condominio,
        "tipo_uso": l.tipo_uso, "n_registros": l.n_registros,
        "area_iptu": l.area_iptu, "area_mdc": round(l.area_mdc, 2),
        "diferenca_pct": None if d is None else round(d, 1),
        "divergencia_relevante": d is not None and abs(d) > lim_div,
        "n_edificacoes": len(l.edificacoes), "altura_mdc": l.altura_mdc_max,
        "altura_legal": h.central, "altura_legal_min": h.minima, "altura_legal_max": h.maxima,
        "fonte_altura": h.fonte, "referencia_altura": h.referencia, "situacao": r["situacao"], "tendencia": r["tendencia"],
        "edificado": r["edificado"], "avisos": l.avisos + h.avisos,
        "altura_topo": None if h.altura_topo is None else round(h.altura_topo, 1),
    }


def _validacoes(d: DadosQuadra, res: dict, g: dict) -> list[dict]:
    out = []
    mdc = res["bases"]["mdc"]
    soma = sum(l.area_mdc for l in d.lotes)
    if d.area_quadra_mdc:
        dif = (soma - d.area_quadra_mdc) / d.area_quadra_mdc * 100
        out.append({"nome": "Soma das áreas MDC dos lotes ≈ área MDC da quadra",
                    "ok": abs(dif) <= g["tolerancia_soma_areas_pct"],
                    "detalhe": f"Soma dos lotes {soma:,.2f} m² × quadra {d.area_quadra_mdc:,.2f} m² "
                               f"(diferença {dif:+.2f}%; tolerância ±{g['tolerancia_soma_areas_pct']}%)."})
    else:
        out.append({"nome": "Soma das áreas MDC dos lotes ≈ área MDC da quadra", "ok": None,
                    "detalhe": "qt_area_quadra_fiscal indisponível; não foi possível conferir."})
    a = d.atribuicao
    out.append({"nome": "Toda edificação atribuída a exatamente um lote",
                "ok": not a["sem_lote"] and not a["em_lotes_sobrepostos"],
                "detalhe": f"{len(a['sem_lote'])} sem lote; {len(a['em_lotes_sobrepostos'])} em lotes sobrepostos "
                           f"(atribuídas ao de maior interseção); {a['fora_da_quadra']} fora da quadra (descartadas)."})
    out.append({"nome": "Lotes sem edificação", "ok": True,
                "detalhe": ", ".join(a["lotes_sem_edificacao"]) or "Nenhum."})
    ruins = [r["lote"].id for r in res["linhas"] if r["altura"].central is not None
             and r["altura"].fonte != "mdc" and r["altura"].altura_mdc is not None
             and r["altura"].central > r["altura"].altura_mdc + 3]
    out.append({"nome": "Altura legal ≤ altura MDC + 3 m", "ok": not ruins,
                "detalhe": ("Revisar (obra posterior a 2007 ou erro de medição): " + ", ".join(ruins))
                           if ruins else "Sem inconsistências."})
    return out


def _alertas(d: DadosQuadra, res: dict, p: Parametros, z: dict) -> list[dict]:
    out = []
    g = f"{p.gabarito_m:g}"
    if z.get("sem_limite"):
        out.append({"nivel": "aviso", "texto": f"A zona {z['sigla']} não tem gabarito máximo no Quadro 3: o teste com {g} m é apenas ilustrativo."})
    elif not z.get("sigla"):
        out.append({"nivel": "aviso", "texto": f"Zona não identificada automaticamente: o teste com {g} m é apenas ilustrativo. Confirme a zona e o gabarito."})
    elif not z.get("na_tabela"):
        out.append({"nivel": "aviso", "texto": f"A zona {z['sigla']} ainda não tem gabarito cadastrado na tabela do Quadro 3: o teste com {g} m é apenas ilustrativo. "
                    "Cadastre o valor em \"Tabela de gabaritos (Quadro 3)\" ou digite o gabarito."})
    elif z.get("gabarito_alterado"):
        out.append({"nivel": "info", "texto": f"Gabarito alterado manualmente para {g} m (Quadro 3 para {z['sigla']}: {z['gabarito_m']:g} m)."})
    if z.get("na_tabela") and not z.get("confirmado"):
        out.append({"nivel": "info", "texto": "Valor do Quadro 3 ainda não confirmado na tabela de configuração."})
    if len(z.get("composicao") or {}) > 1:
        comp = "; ".join(f"{k} {v}%" for k, v in z["composicao"].items())
        out.append({"nivel": "aviso", "texto": f"A quadra tem mais de uma zona ({comp}). Gabarito usado: o da zona "
                    f"{z.get('sigla') or '—'} ({z.get('origem', 'predominante')}). Informe o terreno em estudo para usar a zona dele."})
    mdc_altos = [r["lote"].id for r in res["linhas"] if r["altura"].fonte == "mdc"
                 and (r["altura"].central or 0) >= 15]
    if mdc_altos:
        out.append({"nivel": "aviso", "texto": "Sem medição LiDAR para " + ", ".join(mdc_altos) + ": usada a altura "
                    "MDC (2007), que mede até o topo com barrilete e pode não refletir o prédio atual."})
    novos = [r["lote"].id for r in res["linhas"] if any("posterior a 2007" in a for a in r["altura"].avisos)]
    if novos:
        out.append({"nivel": "destaque", "texto": "Prédios novos ou ampliados depois de 2007 (MDC desatualizado), "
                    "medidos pelo LiDAR 2020: " + ", ".join(novos) + ". Conferir com o Alvará."})
    aticos = [r["lote"].id for r in res["linhas"] if any("cobertura habitável" in a for a in r["altura"].avisos)]
    if aticos:
        out.append({"nivel": "aviso", "texto": "Volume grande sobre a cobertura (ático ou cobertura habitável) em "
                    + ", ".join(aticos) + ": altura mostrada como faixa. Confirmar o uso com o Alvará."})
    if any(r["altura"].fonte == "lidar" for r in res["linhas"]):
        out.append({"nivel": "info", "texto": "Alturas medidas pelo LiDAR 2020 da Prefeitura (laje de cobertura sem "
                    "ático, casa de máquinas e caixa d'água, menos o nível médio da testada). Precisão ±3 m."})
    ingremes = [f"{k} ({v['declividade_pct']:.0f}%)" for k, v in d.medicoes_lidar.items()
                if v.get("declividade_pct") is not None and v["declividade_pct"] > 30]
    if ingremes:
        out.append({"nivel": "aviso", "texto": "Terreno com declividade estimada acima de 30% em " + ", ".join(ingremes)
                    + ". Se confirmada em levantamento topográfico, o gabarito nesses lotes é de 28 m (art. 60, §2º). "
                    "Estimativa pelo MDT; muros de arrimo e escadas podem elevar o valor."})
    for b in ("iptu", "mdc"):
        if res["bases"][b]["sensibilidade"]["muda"]:
            out.append({"nivel": "destaque", "texto": f"Base {b.upper()}: o veredito muda conforme os casos "
                        "\"a confirmar\". Confirme essas alturas com o Alvará."})
            break
    for a in d.avisos_coleta:
        out.append({"nivel": "aviso", "texto": a})
    for f in d.fontes:
        if not f.ok:
            out.append({"nivel": "falha", "texto": f"Fonte indisponível – {f.nome}: {f.erro}"})
    return out


def _fmt(v: float | None) -> str:
    return "—" if v is None else f"{v:.1f}".replace(".", ",") + "%"


def _frase(res: dict, p: Parametros) -> str:
    i, m = res["bases"]["iptu"], res["bases"]["mdc"]
    g = f"{p.gabarito_m:g}".replace(".", ",")
    vals = sorted(x for x in (i["pct_lei"], m["pct_lei"]) if x is not None)
    if not vals:
        return "Não foi possível calcular: faltam dados de lotes."
    if len(vals) == 2 and abs(vals[0] - vals[1]) >= 0.05:
        trecho = f"Entre {_fmt(m['pct_lei'])} (MDC) e {_fmt(i['pct_lei'])} (IPTU)" \
            if m["pct_lei"] <= i["pct_lei"] else f"Entre {_fmt(i['pct_lei'])} (IPTU) e {_fmt(m['pct_lei'])} (MDC)"
    else:
        trecho = _fmt(vals[0])
    return (f"{trecho} da área dos lotes tem edificações acima de {g} m; "
            f"a lei exige mais de 50% (art. 60, II).")
