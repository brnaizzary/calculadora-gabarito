"""Planilha .xlsx com fórmulas vivas, na estrutura da planilha de trabalho da equipe.

Abas: Resumo (gabarito como célula-parâmetro e teste do art. 60, II com fórmulas),
Lotes (áreas IPTU × MDC, diferença, situação calculada por fórmula), Alturas (matriz de
alturas MDC e legal, com a altura legal recalculada a partir das cotas) e Fontes.
Trocar o gabarito, uma área ou uma altura na planilha recalcula todo o resumo.
"""
from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName

FONTE = "Arial"
AZUL, VERDE, PRETO = "0000FF", "008000", "000000"
AMARELO = PatternFill("solid", fgColor="FFFF00")
CINZA = PatternFill("solid", fgColor="F2F4F7")
FINA = Side(style="thin", color="D0D5DD")
BORDA = Border(bottom=FINA)
TIPO = {"condominio": "Condomínio", "fiscal": "Fiscal", "via_acesso": "Via de acesso"}
FONTE_ALT = {"mdc": "MDC 2007", "lidar": "LiDAR 2020", "3d_tiles": "Google 3D", "alvara": "Alvará"}
M2 = '#,##0.00;-#,##0.00;"-"'
M = '0.0;-0.0;"-"'
PCT = '0.0%;-0.0%;"-"'


def f(cor=PRETO, negrito=False, tam=10):
    return Font(name=FONTE, color=cor, bold=negrito, size=tam)


def _cabecalho(ws, linha, titulos, larguras):
    for i, (t, w) in enumerate(zip(titulos, larguras), start=1):
        c = ws.cell(linha, i, t)
        c.font, c.fill, c.border = f(negrito=True), CINZA, BORDA
        c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[linha].height = 30
    ws.freeze_panes = ws.cell(linha + 1, 2)


def gerar_xlsx(r: dict) -> bytes:
    wb = Workbook()
    id_, p = r["identificacao"], r["parametros"]
    lotes = r["lotes"]
    med = r.get("medicoes_lidar", {})
    n = len(lotes)
    ini, fim = 5, 5 + n - 1  # linhas de dados em Lotes e Alturas

    # ------------------------------------------------------------ Resumo
    ws = wb.active
    ws.title = "Resumo"
    ws.column_dimensions["A"].width = 46
    for col in "BCD":
        ws.column_dimensions[col].width = 20
    ws["A1"] = f"Quebra de gabarito – Quadra {id_['setor']}-{id_['quadra']}"
    ws["A1"].font = f(negrito=True, tam=14)
    ws["A2"] = (f"Zona {id_['zona'].get('sigla') or 'não identificada'} (Lei 18.081/2024) · Distrito "
                f"{(id_.get('distrito') or '—').title()} · gerado em {datetime.now(timezone.utc).astimezone():%d/%m/%Y %H:%M}")
    ws["A2"].font = f(cor="475467")
    ws["A3"] = "Células amarelas com texto azul são parâmetros: edite-as e todo o resumo é recalculado."
    ws["A3"].font = f(cor="475467", tam=9)

    ws["A5"], ws["A6"], ws["A7"], ws["A8"] = ("Gabarito de referência (m)", "Tolerância de medição (m)",
                                              "Limite da lei (art. 60, II: mais de)", "Área MDC oficial da quadra (m²)")
    params = [("B5", p["gabarito_m"], M, "Gabarito do Quadro 3 da zona, ou valor de teste. "
               + ("Zona sem gabarito máximo: teste ilustrativo." if p.get("ilustrativo") else "")),
              ("B6", p["tolerancia_m"], M, "Precisão estimada das alturas por modelo 3D (LiDAR). Alvará usa tolerância 0."),
              ("B7", 0.5, PCT, "Lei 16.402/2016, art. 60, II: mais de 50% da área dos lotes."),
              ("B8", r["bases"]["mdc"]["area_quadra"], M2, "qt_area_quadra_fiscal (GeoSampa, camada quadra_fiscal), "
               "inclui lotes sem SQL (vias de acesso).")]
    for ref, val, fmt, nota in params:
        ws[ref] = val
        ws[ref].font, ws[ref].fill, ws[ref].number_format = f(AZUL), AMARELO, fmt
        ws[ref].comment = Comment(nota, "App Quebra de Gabarito")
    for ref in ("A5", "A6", "A7", "A8"):
        ws[ref].font = f()
    wb.defined_names["Gabarito"] = DefinedName("Gabarito", attr_text="Resumo!$B$5")
    wb.defined_names["Tolerancia"] = DefinedName("Tolerancia", attr_text="Resumo!$B$6")
    wb.defined_names["LimiteLei"] = DefinedName("LimiteLei", attr_text="Resumo!$B$7")

    L = lambda col: f"Lotes!${col}${ini}:${col}${fim}"
    ws["A10"], ws["B10"], ws["C10"] = "Teste", "Via IPTU", "Via MDC"
    for c in ("A10", "B10", "C10"):
        ws[c].font, ws[c].fill, ws[c].border = f(negrito=True), CINZA, BORDA
    linhas = [
        ("Área da quadra (m²)", f"=SUM({L('F')})", "=B8", M2),
        ("Área dos lotes acima do gabarito (m²)", f'=SUMIFS({L("F")},{L("N")},"Sim")', f'=SUMIFS({L("G")},{L("N")},"Sim")', M2),
        ("Área dos lotes a confirmar (m²)", f'=SUMIFS({L("F")},{L("N")},"A confirmar")', f'=SUMIFS({L("G")},{L("N")},"A confirmar")', M2),
        ("% da lei (art. 60, II)", "=IF(B11=0,0,B12/B11)", "=IF(C11=0,0,C12/C11)", PCT),
        ("% da lei se 'a confirmar' = Sim", "=IF(B11=0,0,(B12+B13)/B11)", "=IF(C11=0,0,(C12+C13)/C11)", PCT),
        ("Veredito da lei", '=IF(B14>LimiteLei,"SIM",IF(B15>LimiteLei,"A CONFIRMAR","NÃO"))',
         '=IF(C14>LimiteLei,"SIM",IF(C15>LimiteLei,"A CONFIRMAR","NÃO"))', None),
        ("Área dos lotes edificados (m²)", f'=SUMIFS({L("F")},{L("E")},"Sim")', f'=SUMIFS({L("G")},{L("E")},"Sim")', M2),
        ("% edificada (critério interno ≥ 50%)", "=IF(B11=0,0,B17/B11)", "=IF(C11=0,0,C17/C11)", PCT),
        ("% acima do gabarito sobre a edificada (≥ 50%)", "=IF(B17=0,0,B12/B17)", "=IF(C17=0,0,C12/C17)", PCT),
        ("Veredito do critério interno (secundário)", '=IF(AND(B18>=0.5,B19>=0.5),"SIM","NÃO")',
         '=IF(AND(C18>=0.5,C19>=0.5),"SIM","NÃO")', None),
    ]
    for i, (rot, fi, fm, fmt) in enumerate(linhas, start=11):
        ws.cell(i, 1, rot).font = f()
        for col, val in ((2, fi), (3, fm)):
            c = ws.cell(i, col, val)
            c.font = f(negrito=rot.startswith("Veredito"))
            if fmt:
                c.number_format = fmt
            c.border = BORDA
    ws["A22"], ws["B22"] = "QUEBRA DE GABARITO (veredito geral)", '=IF(B16=C16,B16,"A CONFIRMAR")'
    ws["A22"].font, ws["B22"].font = f(negrito=True, tam=12), f(negrito=True, tam=12)
    ws["A23"] = "Se IPTU e MDC divergirem, o veredito é A CONFIRMAR (decisão da diretoria, 15/10/2026)."
    ws["A23"].font = f(cor="475467", tam=9)
    ws["A24"], ws["B24"] = "Conferência: soma das áreas MDC dos lotes (m²)", f"=SUM({L('G')})"
    ws["B24"].number_format = M2
    ws["A25"], ws["B25"] = "Diferença para a área oficial", "=IF(B8=0,0,(B24-B8)/B8)"
    ws["B25"].number_format = '0.00%'
    for ref in ("A24", "A25", "B24", "B25"):
        ws[ref].font = f(cor="475467", tam=9)
    ws["A27"] = r["aviso_escopo"]
    ws["A27"].font = f(cor="B42318", negrito=True)

    # ------------------------------------------------------------ Alturas
    wa = wb.create_sheet("Alturas")
    wa["A1"] = "Matriz de alturas – MDC (2007) e altura legal (laje − térreo)"
    wa["A1"].font = f(negrito=True, tam=12)
    wa["A2"] = ("Altura legal LiDAR = cota da laje − nível médio da testada (fórmula). Para usar um Alvará, digite a "
                "altura em 'Altura legal' e troque a fonte para 'Alvará' (alturas manuais do app aparecem como 'Manual: <referência>').")
    wa["A2"].font = f(cor="475467", tam=9)
    titulos = ["Lote", "Nº edificações", "Altura MDC (m)", "Cota da laje (m)", "Cota do topo c/ barrilete (m)",
               "Nível médio da testada (m)", "Desnível da testada (m)", "Maior cota da testada (m)",
               "Menor cota da testada (m)", "Altura legal (m)", "Mínima (m)", "Máxima (m)", "Fonte da altura",
               "Altura até o topo (m)", "Declividade do lote (%)"]
    _cabecalho(wa, 4, titulos, [10, 9, 10, 11, 12, 12, 11, 11, 11, 11, 10, 10, 12, 11, 11])
    for i, l in enumerate(lotes, start=ini):
        m = med.get(l["id"], {})
        fonte = FONTE_ALT.get(l["fonte_altura"], l["fonte_altura"]) if l["n_edificacoes"] else ""
        if l.get("referencia_altura"):
            fonte = f"Manual: {l['referencia_altura']}"  # tolerância 0, como o Alvará
        vals = [l["id"], l["n_edificacoes"], l["altura_mdc"], m.get("z_laje"), m.get("z_topo"),
                m.get("nivel_medio_testada"), m.get("desnivel_testada"), m.get("cota_maior_testada"),
                m.get("cota_menor_testada")]
        for j, v in enumerate(vals, start=1):
            c = wa.cell(i, j, v)
            c.font = f(AZUL if j > 1 else PRETO)
            c.number_format = M if j > 2 else "General"
        lidar = l["fonte_altura"] == "lidar" and m.get("z_laje") is not None and m.get("nivel_medio_testada") is not None
        if lidar:
            wa.cell(i, 10, f"=D{i}-F{i}")
            wa.cell(i, 11, f"=IF(G{i}<=2,D{i}-(F{i}+1),D{i}-H{i})")
            wa.cell(i, 12, f"=IF(G{i}<=2,D{i}-F{i},D{i}-I{i})")
            wa.cell(i, 14, f'=IF(E{i}="","",E{i}-F{i})')
            for j in (10, 11, 12, 14):
                wa.cell(i, j).font = f()
        else:
            for j, v in ((10, l["altura_legal"]), (11, l["altura_legal_min"]), (12, l["altura_legal_max"]),
                         (14, l.get("altura_topo"))):
                wa.cell(i, j, v).font = f(AZUL)
        for j in (10, 11, 12, 14):
            wa.cell(i, j).number_format = M
        wa.cell(i, 13, fonte).font = f(AZUL)
        dec = m.get("declividade_pct")
        c = wa.cell(i, 15, None if dec is None else dec / 100)
        c.font, c.number_format = f(AZUL), PCT

    # ------------------------------------------------------------ Lotes
    wl = wb.create_sheet("Lotes", 1)
    wl["A1"] = "Lotes da quadra – áreas IPTU × MDC e situação em relação ao gabarito"
    wl["A1"].font = f(negrito=True, tam=12)
    wl["A2"] = ("Áreas: IPTU = qt_area_terreno (cadastro fiscal); MDC = área do polígono do lote (fórmula de Gauss). "
                "Alturas vêm da aba Alturas (verde). 'Acima do gabarito' é calculado por fórmula.")
    wl["A2"].font = f(cor="475467", tam=9)
    titulos = ["Lote", "SQL", "Endereço", "Tipo", "Edificado (critério interno)", "Área IPTU (m²)", "Área MDC (m²)",
               "Diferença MDC × IPTU", "Altura legal (m)", "Mínima (m)", "Máxima (m)", "Fonte da altura",
               "Tolerância aplicada (m)", "Acima do gabarito", "Nº edificações"]
    _cabecalho(wl, 4, titulos, [10, 17, 28, 13, 12, 13, 13, 12, 11, 10, 10, 12, 11, 14, 10])
    for i, l in enumerate(lotes, start=ini):
        vals = [l["id"], l["sql"] or (f"Condomínio {l['condominio']}" if l["condominio"] else ""), l["endereco"] or "",
                TIPO.get(l["tipo"], l["tipo"]), "Sim" if l["edificado"] else "Não", l["area_iptu"], l["area_mdc"]]
        for j, v in enumerate(vals, start=1):
            c = wl.cell(i, j, v)
            c.font = f(AZUL if j >= 5 else PRETO)
            if j in (6, 7):
                c.number_format = M2
        wl.cell(i, 8, f'=IF(OR(F{i}="",F{i}=0),"",(G{i}-F{i})/F{i})').number_format = '+0%;-0%;0%'
        for j, col in ((9, "J"), (10, "K"), (11, "L"), (12, "M"), (15, "B")):
            c = wl.cell(i, j, f'=IF(Alturas!{col}{i}="","",Alturas!{col}{i})')
            c.font = f(VERDE)
            if j <= 11:
                c.number_format = M
        wl.cell(i, 13, f'=IF(OR(L{i}="Alvará",LEFT(L{i},7)="Manual:"),0,Tolerancia)').number_format = M
        wl.cell(i, 14, f'=IF(O{i}=0,"Sem edificação",IF(I{i}="","Sem medição",IF(J{i}-M{i}>Gabarito,"Sim",'
                       f'IF(K{i}+M{i}<=Gabarito,"Não","A confirmar"))))')
        for j in (8, 13, 14):
            wl.cell(i, j).font = f()
    wl.cell(fim + 2, 1, "Divergência relevante: |diferença| > 10% (formatação condicional em vermelho).").font = f(cor="475467", tam=9)
    from openpyxl.formatting.rule import FormulaRule
    wl.conditional_formatting.add(f"H{ini}:H{fim}", FormulaRule(formula=[f'AND(H{ini}<>"",ABS(H{ini})>0.1)'],
                                                                font=Font(name=FONTE, color="C4320A", bold=True)))
    wl.conditional_formatting.add(f"N{ini}:N{fim}", FormulaRule(formula=[f'N{ini}="Sim"'],
                                                                fill=PatternFill("solid", fgColor="F4C7C3")))
    wl.conditional_formatting.add(f"N{ini}:N{fim}", FormulaRule(formula=[f'N{ini}="A confirmar"'],
                                                                fill=PatternFill("solid", fgColor="FDE7A6")))

    # ------------------------------------------------------------ Fontes
    wf = wb.create_sheet("Fontes")
    wf.column_dimensions["A"].width = 48
    wf.column_dimensions["B"].width = 22
    wf.column_dimensions["C"].width = 90
    wf["A1"] = "Fontes, datas de consulta e método"
    wf["A1"].font = f(negrito=True, tam=12)
    _cabecalho(wf, 3, ["Fonte", "Consultado em", "Endereço / erro"], [48, 22, 90])
    wf.freeze_panes = None
    for i, fo in enumerate(r["fontes"], start=4):
        wf.cell(i, 1, fo["nome"]).font = f()
        wf.cell(i, 2, fo["consultado_em"] or "").font = f()
        wf.cell(i, 3, fo["erro"] or fo["url"] or "").font = f(cor="B42318" if fo["erro"] else "475467", tam=8)
    k = 5 + len(r["fontes"])
    wf.cell(k, 1, "Limitações").font = f(negrito=True)
    for j, t in enumerate(r["limitacoes"], start=k + 1):
        wf.cell(j, 1, "• " + t).font = f(tam=9)
    wf.cell(j + 2, 1, r["aviso_escopo"]).font = f(cor="B42318", negrito=True)

    for w in wb.worksheets:
        w.sheet_view.showGridLines = w.title != "Resumo"
    from openpyxl.workbook.properties import CalcProperties
    wb.calculation = CalcProperties(fullCalcOnLoad=True)  # o openpyxl não grava valores; o Excel calcula ao abrir
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
