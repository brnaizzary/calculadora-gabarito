"""Mapa da quadra em SVG, gerado no servidor (o mesmo desenho vai para a tela e para o PDF).

Lotes coloridos pela situação (acima do gabarito em vermelho, "a confirmar" em amarelo,
demais em cinza), edificações MDC por cima, rótulos com altura legal e área (IPTU ou MDC),
terreno em estudo tracejado, nomes das ruas, norte e escala.
"""
from __future__ import annotations

import math
from html import escape

from shapely.geometry import LineString, Point
from shapely.geometry.base import BaseGeometry

from .modelo import Lote

CORES = {
    "sim": ("#f4c7c3", "#b42318"),
    "a_confirmar": ("#fde7a6", "#8a6100"),
    "nao": ("#e4e7ec", "#667085"),
    "sem_edificacao": ("#f2f4f7", "#98a2b3"),
    "sem_medicao": ("#f2f4f7", "#98a2b3"),
}
MARGEM_M = 28


def _fmt(v: float, casas: int = 0) -> str:
    return f"{v:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def rotulos_ruas(lotes: list[Lote], geom_q: BaseGeometry) -> list[dict]:
    """Posição e ângulo do nome de cada rua: média dos trechos de testada dos lotes com
    aquele logradouro, deslocada para fora da quadra e alinhada à borda mais próxima."""
    borda = geom_q.boundary
    por_rua: dict[str, list[Point]] = {}
    for l in lotes:
        if not l.endereco:
            continue
        rua = l.endereco.split(",")[0].strip()
        trecho = l.geom.boundary.intersection(borda.buffer(0.5))
        if not trecho.is_empty and trecho.length > 0.5:
            por_rua.setdefault(rua, []).append(trecho.centroid)
    out, c = [], geom_q.centroid
    for rua, pts in por_rua.items():
        mx = sum(p.x for p in pts) / len(pts)
        my = sum(p.y for p in pts) / len(pts)
        na_borda = borda.interpolate(borda.project(Point(mx, my)))
        d = borda.project(na_borda)
        a, b = borda.interpolate(max(d - 3, 0)), borda.interpolate(min(d + 3, borda.length))
        ang = math.degrees(math.atan2(b.y - a.y, b.x - a.x))
        vx, vy = na_borda.x - c.x, na_borda.y - c.y
        n = math.hypot(vx, vy) or 1
        out.append({"nome": rua, "x": na_borda.x + vx / n * 11, "y": na_borda.y + vy / n * 11, "angulo": ang})
    return out


def _caminho(geom: BaseGeometry, tx, ty) -> str:
    partes = []
    polys = [geom] if geom.geom_type == "Polygon" else list(getattr(geom, "geoms", []))
    for p in polys:
        if p.geom_type != "Polygon":
            continue
        for anel in [p.exterior, *p.interiors]:
            pts = " L".join(f"{tx(x):.1f},{ty(y):.1f}" for x, y in anel.coords)
            partes.append(f"M{pts}Z")
    return " ".join(partes)


def svg_quadra(lotes: list[Lote], linhas: list[dict], geom_q: BaseGeometry, modo: str = "mdc",
               estudo: set[str] | None = None, gabarito_m: float | None = None,
               largura_px: int = 900, limite_div_pct: float = 10.0) -> str:
    estudo = estudo or set()
    x0, y0, x1, y1 = geom_q.bounds
    x0, y0, x1, y1 = x0 - MARGEM_M, y0 - MARGEM_M, x1 + MARGEM_M, y1 + MARGEM_M
    esc = largura_px / (x1 - x0)
    altura_px = (y1 - y0) * esc
    rodape = 34  # faixa abaixo do desenho: escala e legenda, sem cobrir a quadra
    tx = lambda x: (x - x0) * esc
    ty = lambda y: (y1 - y) * esc
    por_id = {r["id"]: r for r in linhas}

    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {largura_px} {altura_px + rodape:.0f}" '
         f'width="100%" font-family="Helvetica, Arial, sans-serif" role="img" '
         f'aria-label="Mapa da quadra, áreas {modo.upper()}">',
         '<defs><pattern id="hach" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
         '<line x1="0" y1="0" x2="0" y2="6" stroke="#c4320a" stroke-width="1.2"/></pattern></defs>',
         f'<rect width="100%" height="100%" fill="#ffffff"/>',
         f'<path d="{_caminho(geom_q.buffer(6, join_style=2), tx, ty)}" fill="#f5f6f8" stroke="none"/>']

    # lotes
    for l in lotes:
        r = por_id.get(l.id, {})
        fill, stroke = CORES.get(r.get("situacao", "sem_edificacao"), CORES["nao"])
        dica = [l.id, l.endereco or "", f"Área MDC {_fmt(l.area_mdc, 2)} m²",
                f"Área IPTU {_fmt(l.area_iptu, 2)} m²" if l.area_iptu else "Sem área IPTU"]
        if r.get("altura_legal") is not None:
            dica.append(f"Altura legal {_fmt(r['altura_legal'], 1)} m ({r.get('fonte_altura')})")
        s.append(f'<path data-lote="{escape(l.id)}" d="{_caminho(l.geom, tx, ty)}" fill="{fill}" stroke="{stroke}" stroke-width="0.8">'
                 f'<title>{escape(" · ".join(x for x in dica if x))}</title></path>')
        div = r.get("diferenca_pct")
        if modo == "iptu" and div is not None and abs(div) > limite_div_pct:
            s.append(f'<path d="{_caminho(l.geom, tx, ty)}" fill="url(#hach)" fill-opacity="0.35" '
                     f'stroke="#c4320a" stroke-width="1.6" pointer-events="none"/>')

    # edificações
    for l in lotes:
        for e in l.edificacoes:
            s.append(f'<path d="{_caminho(e.geom, tx, ty)}" fill="none" '
                     f'stroke="#344054" stroke-width="0.7" stroke-opacity="0.75" pointer-events="none"/>')

    s.append(f'<path d="{_caminho(geom_q, tx, ty)}" fill="none" stroke="#231f1b" stroke-width="1.6"/>')

    # terreno em estudo
    for l in lotes:
        if l.id in estudo or (l.sql and l.sql in estudo):
            s.append(f'<path d="{_caminho(l.geom, tx, ty)}" fill="none" stroke="#1d4ed8" stroke-width="2.6" '
                     f'stroke-dasharray="7 4" pointer-events="none"/>')

    # rótulos dos lotes
    for l in lotes:
        r = por_id.get(l.id, {})
        p = l.geom.representative_point()
        area = l.area_mdc if modo == "mdc" else l.area_iptu
        tam = 11 if l.area_mdc > 450 else 9 if l.area_mdc > 240 else 7
        linhas_txt = [l.id]
        if l.area_mdc > 240:
            if r.get("altura_legal") is not None and r.get("n_edificacoes"):
                linhas_txt.append(f"{_fmt(r['altura_legal'], 1)} m")
            linhas_txt.append(f"{_fmt(area)} m²" if area else "s/ IPTU")
            div = r.get("diferenca_pct")
            if modo == "iptu" and div is not None and abs(div) > limite_div_pct:
                linhas_txt.append(f"{'+' if div > 0 else ''}{_fmt(div)}%")
        y = ty(p.y) - (len(linhas_txt) - 1) * tam * 0.6
        for i, t in enumerate(linhas_txt):
            peso = "700" if i == 0 else "400"
            cor = "#c4320a" if t.endswith("%") else "#1c2430"
            # halo branco e texto em camadas separadas (o WeasyPrint não suporta paint-order)
            base = (f'x="{tx(p.x):.1f}" y="{y + i * tam * 1.15 + tam * 0.35:.1f}" font-size="{tam}" '
                    f'font-weight="{peso}" text-anchor="middle" pointer-events="none"')
            s.append(f'<text {base} fill="#fff" stroke="#fff" stroke-width="2.5" stroke-linejoin="round">{escape(t)}</text>'
                     f'<text {base} fill="{cor}">{escape(t)}</text>')

    # ruas
    for rua in rotulos_ruas(lotes, geom_q):
        ang = -rua["angulo"]
        if ang > 90:
            ang -= 180
        if ang < -90:
            ang += 180
        s.append(f'<text x="{tx(rua["x"]):.1f}" y="{ty(rua["y"]):.1f}" font-size="12" font-style="italic" '
                 f'fill="#475467" text-anchor="middle" letter-spacing="0.5" '
                 f'transform="rotate({ang:.1f} {tx(rua["x"]):.1f} {ty(rua["y"]):.1f})">{escape(rua["nome"])}</text>')

    # norte e escala
    nx, ny = largura_px - 34, 30
    s.append(f'<g transform="translate({nx},{ny})"><path d="M0,-18 L8,8 L0,3 L-8,8 Z" fill="#231f1b"/>'
             f'<text y="22" font-size="11" font-weight="700" text-anchor="middle">N</text></g>')
    passo = 20 if (x1 - x0) < 250 else 50
    bx, by = 16, altura_px + 24
    s.append(f'<rect x="0" y="{altura_px:.0f}" width="{largura_px}" height="{rodape}" fill="#fff"/>'
             f'<line x1="0" y1="{altura_px:.0f}" x2="{largura_px}" y2="{altura_px:.0f}" stroke="#e4e7ec"/>')
    s.append(f'<g font-size="10" fill="#344054"><rect x="{bx}" y="{by - 5}" width="{passo * esc / 2:.1f}" height="5" fill="#231f1b"/>'
             f'<rect x="{bx + passo * esc / 2:.1f}" y="{by - 5}" width="{passo * esc / 2:.1f}" height="5" fill="#fff" stroke="#231f1b"/>'
             f'<text x="{bx}" y="{by - 9}">0</text><text x="{bx + passo * esc:.1f}" y="{by - 9}" text-anchor="middle">{passo} m</text></g>')

    g = f"{gabarito_m:g}".replace(".", ",") if gabarito_m else "?"
    itens = [(CORES["sim"], "", f"Acima de {g} m"), (CORES["a_confirmar"], "", "A confirmar (±3 m)"),
             (CORES["nao"], "", "Abaixo"), (CORES["sem_edificacao"], "", "Sem edificação")]
    if modo == "iptu":
        itens.append((("url(#hach)", "#c4320a"), "", f"MDC × IPTU difere > {limite_div_pct:g}%"))
    if estudo:
        itens.append((("none", "#1d4ed8"), ' stroke-width="2" stroke-dasharray="4 2"', "Terreno em estudo"))
    larguras = [24 + len(t) * 5.6 for *_, t in itens]
    lx = largura_px - 12 - sum(larguras)
    s.append('<g font-size="10" fill="#344054">')
    for ((f, st), extra, t), w in zip(itens, larguras):
        s.append(f'<rect x="{lx:.1f}" y="{by - 9}" width="14" height="10" fill="{f}" stroke="{st}"{extra}/>'
                 f'<text x="{lx + 19:.1f}" y="{by}">{escape(t)}</text>')
        lx += w
    s.append("</g>")
    s.append("</svg>")
    return "".join(s)
